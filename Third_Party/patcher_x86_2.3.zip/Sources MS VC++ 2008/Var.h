#include "Base.h"


struct _VarTree_;

NOALIGN struct _Var_
{
	virtual _dword_ __stdcall GetValue();
	virtual void __stdcall SetValue(_dword_ v);
	virtual _dword_* __stdcall GetPValue();

	_dword_ value;

	_Var_* link[2];
	short balance;
	
	char* name;

	_VarTree_* sub_tree;
	
	_Var_(char* name_, _dword_ value_);
};


NOALIGN class _VarTree_
{
public:
	_Var_* root;
	int count;

	_VarTree_();
	_Var_* Add(char* name, _dword_ value);
	_Var_* Find(char* name);
};
