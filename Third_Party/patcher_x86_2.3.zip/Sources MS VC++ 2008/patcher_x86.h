#pragma once


#define	_byte_ unsigned __int8
#define	_word_ unsigned __int16
#define	_dword_ unsigned __int32

// _bool_ - 4-� �������� ���������� ���, ��� BOOL � Win32 API
// ���� ����� ���������, ����� �������� �� int ��� ������������ bool ��������
#define	_bool_ __int32

// ��� ������ � ����� ���������� ���������� ���� �����,
// ���� ��� ������� ��-�������, ������ �������� _ptr_ �� ����� ������ ���, void* ��� int ��������
typedef _dword_	_ptr_;

#pragma pack(push, 4)
struct HookContext
{
	int eax;
	int ecx;
	int edx;
	int ebx;
	int esp;
	int ebp;
	int esi;
	int edi;

	_ptr_	return_address;
};

#define EXEC_DEFAULT	1
#define NO_EXEC_DEFAULT 0


#define PATCH_  0
#define LOHOOK_ 1
#define HIHOOK_ 2


class IPatch
{
public:
	virtual _ptr_	GetAddress() = 0;
	virtual _dword_	GetSize() = 0;
	virtual char*	GetOwner() = 0;
	virtual int		GetType() = 0;

	virtual _bool_	IsApplied() = 0;
	virtual _bool_	Apply() = 0;
	virtual _bool_	Undo() = 0;
	virtual _bool_	Destroy() = 0;

	virtual IPatch* GetAppliedBefore() = 0;
	virtual IPatch* GetAppliedAfter() = 0;
};

#define STATE_RUNNING 1
#define STATE_WANT_UNDO 2
#define STATE_WANT_DESTROY 3

class ILoHook : public IPatch
{
public:
	virtual _ptr_	GetAddress() = 0;
	virtual _dword_	GetSize() = 0;
	virtual char*	GetOwner() = 0;
	virtual int		GetType() = 0;

	virtual _bool_	IsApplied() = 0;
	virtual _bool_	Apply() = 0;
	virtual _bool_	Undo() = 0;
	virtual _bool_	Destroy() = 0;

	virtual IPatch* GetAppliedBefore() = 0;
	virtual IPatch* GetAppliedAfter() = 0;
};

#define CALL_ 0
#define SPLICE_ 1
#define FUNCPTR_ 2

#define DIRECT_ 0
#define EXTENDED_ 1

#define ANY_		0
#define STDCALL_	0
#define THISCALL_	1
#define FASTCALL_	2
#define CDECL_		3

class IHiHook : public IPatch
{
public:
	virtual _ptr_	GetAddress() = 0;
	virtual _dword_	GetSize() = 0;
	virtual char*	GetOwner() = 0;
	virtual int		GetType() = 0;

	virtual _bool_	IsApplied() = 0;
	virtual _bool_	Apply() = 0;
	virtual _bool_	Undo() = 0;
	virtual _bool_	Destroy() = 0;

	virtual IPatch* GetAppliedBefore() = 0;
	virtual IPatch* GetAppliedAfter() = 0;

	virtual _ptr_ GetDefaultFunc() = 0;
	virtual _ptr_ GetOriginalFunc() = 0;
	virtual _ptr_ GetReturnAddress() = 0;
};


class IPatcherInstance
{
public:
	virtual IPatch* Write(_ptr_ address, _ptr_ data, _dword_ size, _bool_ is_code = 0) = 0;
	virtual IPatch* WriteByte(_ptr_ address, int value) = 0;
	virtual IPatch* WriteWord(_ptr_ address, int value) = 0;
	virtual IPatch* WriteDword(_ptr_ address, int value) = 0;
	virtual IPatch* WriteJmp(_ptr_ address, _ptr_ to) = 0;
	virtual IPatch* WriteHexString(_ptr_ address, char* hex_str) = 0;
	virtual IPatch* WriteComplexVA(_ptr_ address, char* format, _dword_* va_args) = 0;
	virtual ILoHook* WriteLoHook(_ptr_ address, void* func) = 0;
	virtual IHiHook* WriteHiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* new_func) = 0;

	virtual IPatch* CreatePatch(_ptr_ address, _ptr_ data, _dword_ size, _bool_ is_code = 0) = 0;
	virtual IPatch* CreateBytePatch(_ptr_ address, int value) = 0;
	virtual IPatch* CreateWordPatch(_ptr_ address, int value) = 0;
	virtual IPatch* CreateDwordPatch(_ptr_ address, int value) = 0;
	virtual IPatch* CreateJmpPatch(_ptr_ address, _ptr_ to) = 0;
	virtual IPatch* CreateHexStringPatch(_ptr_ address, char* hex_str) = 0;
	virtual IPatch* CreateComplexPatchVA(_ptr_ address, char* format, _dword_* va_args) = 0;
	virtual ILoHook* CreateLoHook(_ptr_ address, void* func) = 0;
	virtual IHiHook* CreateHiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* new_func) = 0;
	
	virtual _bool_ ApplyAll() = 0;
	virtual _bool_ UndoAll() = 0;
	virtual _bool_ DestroyAll() = 0;


	inline IPatch* WriteComplex(_ptr_ address, char* format, ...)
	{
		return WriteComplexVA(address, format, (_dword_*)((_ptr_)&format + 4));
	}
	inline IPatch* CreateComplexPatch(_ptr_ address, char* format, ...)
	{
		return CreateComplexPatchVA(address, format, (_dword_*)((_ptr_)&format + 4));
	}
};

class IPatcher
{
public:
	virtual IPatcherInstance* CreateInstance(char* owner) = 0;
	virtual IPatcherInstance*  GetInstance(char* owner) = 0;
	virtual _bool_ GetPatchesAt(_ptr_ in_address, IPatch*** out_patches,  int* out_count) = 0;
	virtual void SaveDump(char* file_name) = 0;
	virtual int GetMaxPatchSize() = 0;
	
	virtual int WriteComplexStringVA(_ptr_ address, char* format, _dword_* args) = 0;
	virtual int GetOpcodeLength(_ptr_ p_opcode) = 0;
	virtual void MemCopyCode(_ptr_ dst, _ptr_ src, _dword_ size) = 0;
	

	inline _ptr_ WriteComplexString(_ptr_ address, char* format, ...)
	{
		return WriteComplexStringVA(address, format, (_dword_*)((_ptr_)&format + 4));
	}
};
#pragma pack(pop)

