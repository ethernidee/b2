#pragma once
#include "Base.h"

template<typename ItemPointerType>
class _PointerListNode_
{
public:
	ItemPointerType* p_item;
	_PointerListNode_* next;
	_PointerListNode_* prev;

	_PointerListNode_(ItemPointerType* p_item)
	{
		this->p_item = p_item;
		next = prev = NULL;
	}
};

template<typename ItemPointerType>
class _PointerList_
{
public:
	_PointerListNode_<ItemPointerType>* first;
	_PointerListNode_<ItemPointerType>* last;
	int count;

	_PointerList_()
	{
		first = last = NULL;
		count = 0;
	}

	int Add(ItemPointerType* p_item)
	{
		_PointerListNode_<ItemPointerType>* node = new _PointerListNode_<ItemPointerType>(p_item);
		if (count == 0)
		{
			first = node;
			last = node;
			count++;
			return 1;
		}
		node->prev = last;
		last->next = node;
		last = node;
		count++;
		return 1;
	}

	ItemPointerType* operator[](int index)
	{
		int i;
		_PointerListNode_<ItemPointerType>* node;
		if (count == 0) return NULL;
		for (node = first; node != NULL; node = node->next, i++)
			if (i == index) break;
		if (i >= count) return NULL;
		return node;
	}

	ItemPointerType* Remove(ItemPointerType* p_item)
	{
		_PointerListNode_<ItemPointerType>* node;
		
		if (count == 0) return NULL;

		if ((count == 1) && (first->p_item == p_item))
		{
			delete first;
			first = last = NULL;
			count--;
			return p_item;
		}
		
		for (node = first; node != NULL; node = node->next)
		{
			if (node->p_item == p_item)
			{
				if (node == first)
				{
					first = node->next;
					first->prev = NULL;
				}
				else if (node == last)
				{
					last = node->prev;
					last->next = NULL;
				}
				else
				{
					node->prev->next = node->next;
					node->next->prev = node->prev;
				}
				delete node;
				count--;
				return p_item;
			}
		}
		return NULL;
	}

	void Clear()
	{
		_PointerListNode_<ItemPointerType> *node, *next_node;
		
		if (count == 0) return;

		node = first;
		while(true)
		{
			next_node = node->next;
			delete node;
			if (next_node == NULL) break;
			node = next_node;

		}
		first = last = NULL;
		count = 0;
	}
};