#pragma once

#include "_Array_.h"
#include "_PointerList_.h"
#include "Var.h"


#define __EXPORT extern "C" __declspec(dllexport)


#define MAX_PATCH_SIZE 8192


class Patch;

#define EXEC_DEFAULT	1
#define NO_EXEC_DEFAULT 0


#define PATCH_  0
#define LOHOOK_ 1
#define HIHOOK_ 2


struct PatchNode;
class PatcherInstance;

NOALIGN struct HookContext
{
	int eax;
	int ecx;
	int edx;
	int ebx;
	int esp;
	int ebp;
	int esi;
	int edi;

	_ptr_	return_address;

	_dword_ flags;
};



#define PF_APPLIED		0x01
#define PF_CODE			0x02
#define PF_LOHOOK		0x04
#define PF_HIHOOK		0x08
#define PF_FIXED		0x10


NOALIGN class Patch
{
public:
	virtual _ptr_	__stdcall GetAddress();
	virtual _dword_	__stdcall GetSize();
	virtual char*	__stdcall GetOwner();
	virtual int		__stdcall GetType();

	virtual _bool_	__stdcall IsApplied();
	virtual _bool_	__stdcall Apply();
	virtual _bool_	__stdcall ApplyInsert(int zorder);
	virtual int	__stdcall Undo();
	virtual int	__stdcall Destroy();

	virtual Patch* __stdcall GetAppliedBefore();
	virtual Patch* __stdcall GetAppliedAfter();

public:
	_ptr_ address;
	_ptr_ old_data;
	_ptr_ new_data;

	PatchNode* node;
	PatcherInstance* parent;

	_word_ size;
	_word_ flags;

	Patch(_ptr_ address, _ptr_ new_data, _word_ size, _bool_ is_code = 0);
	inline Patch(){}
	~Patch();
};


NOALIGN class LoHook : public Patch
{
public:
	virtual _ptr_	__stdcall GetAddress();
	virtual _dword_	__stdcall GetSize();
	virtual char*	__stdcall GetOwner();
	virtual int		__stdcall GetType();

	virtual _bool_	__stdcall IsApplied();
	virtual _bool_	__stdcall Apply();
	virtual _bool_	__stdcall ApplyInsert(int zorder);
	virtual int	__stdcall Undo();
	virtual int	__stdcall Destroy();

	virtual Patch* __stdcall GetAppliedBefore();
	virtual Patch* __stdcall GetAppliedAfter();

public:
	_ptr_ func; 
	_ptr_ bridge_to_func;		// ��������� �� ���� � func
	_ptr_ tail_code;			// ��������� �� ���������(��������) ��� � �����

	_dword_ esp_register;
	_dword_ return_address;
	_dword_ flags_register;
	HookContext* context;

	LoHook(_ptr_ address, void* func, _dword_ stack_delta = 128);
	~LoHook();
};


NOALIGN class HexHook : public Patch
{
public:
	virtual _ptr_	__stdcall GetAddress();
	virtual _dword_	__stdcall GetSize();
	virtual char*	__stdcall GetOwner();
	virtual int		__stdcall GetType();

	virtual _bool_	__stdcall IsApplied();
	virtual _bool_	__stdcall Apply();
	virtual _bool_	__stdcall ApplyInsert(int zorder);
	virtual int	__stdcall Undo();
	virtual int	__stdcall Destroy();

	virtual Patch* __stdcall GetAppliedBefore();
	virtual Patch* __stdcall GetAppliedAfter();

public:
	_ptr_ code; 
	_ptr_ tail_code;			// ��������� �� ���������(��������) ��� � �����
	_bool_ exec_default;


	HexHook(_ptr_ address, _bool_ exec_default, _dword_ func_code_size, _ptr_ func_code);
	~HexHook();
};


#define CALL_		0
#define SPLICE_		1
#define FUNCPTR_	2

#define DIRECT_		0
#define EXTENDED_	1
#define SAFE_		2

#define STDCALL_	0
#define THISCALL_	1
#define FASTCALL_	2
#define CDECL_		3

NOALIGN class HiHook : public Patch
{
public:
	virtual _ptr_	__stdcall GetAddress();
	virtual _dword_	__stdcall GetSize();
	virtual char*	__stdcall GetOwner();
	virtual int		__stdcall GetType();

	virtual _bool_	__stdcall IsApplied();
	virtual _bool_	__stdcall Apply();
	virtual _bool_	__stdcall ApplyInsert(int zorder);
	virtual int	__stdcall Undo();
	virtual int	__stdcall Destroy();

	virtual Patch* __stdcall GetAppliedBefore();
	virtual Patch* __stdcall GetAppliedAfter();


	virtual _ptr_ __stdcall GetDefaultFunc();
	virtual _ptr_ __stdcall GetOriginalFunc();
	virtual _ptr_ __stdcall GetReturnAddress();

	virtual void __stdcall SetUserData(_dword_ data);
	virtual _dword_ __stdcall GetUserData();

public:

	_ptr_ new_func; 
	_ptr_ default_func; 
	_ptr_ bridge_to_new;		// ��������� �� ���� � new_func
	_ptr_ bridge_to_default;    // ��������� �� ���� � func
	_ptr_ return_address; 
	HookContext* context; 
	_dword_ user_data;

	_byte_ hooktype : 3;
	_byte_ subtype  : 2;
	_byte_ calltype : 3;


	HiHook(_ptr_ address, int type, int subtype, int calltype, void* new_func);
	~HiHook();
};


NOALIGN class PatchNode
{
public:
	PatchNode* link[2];
	_Array_<Patch*,sizeof(Patch*)> patches;
	short balance;

	PatchNode();
	~PatchNode();
};


NOALIGN class PatchTree
{
public:
	PatchNode* root;
	int count;
	int patches_count;

	PatchTree();
	int Add(Patch* patch);
	int Remove(Patch* patch);
	PatchNode* Find(_ptr_ address);
};



NOALIGN class PatcherInstance
{
public:
	// ver 1.0:
	virtual Patch* __stdcall WriteByte(_ptr_ address, int value);
	virtual Patch* __stdcall WriteWord(_ptr_ address, int value);
	virtual Patch* __stdcall WriteDword(_ptr_ address, int value);
	virtual Patch* __stdcall WriteJmp(_ptr_ address, _ptr_ to);
	virtual Patch* __stdcall WriteHexPatch(_ptr_ address, char* hex_str);
	virtual Patch* __stdcall WriteCodePatchVA(_ptr_ address, char* format, _dword_* va_args);
	virtual LoHook* __stdcall WriteLoHook(_ptr_ address, void* func);
	virtual HiHook* __stdcall WriteHiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* new_func);

	virtual Patch* __stdcall CreateBytePatch(_ptr_ address, int value);
	virtual Patch* __stdcall CreateWordPatch(_ptr_ address, int value);
	virtual Patch* __stdcall CreateDwordPatch(_ptr_ address, int value);
	virtual Patch* __stdcall CreateJmpPatch(_ptr_ address, _ptr_ to);
	virtual Patch* __stdcall CreateHexPatch(_ptr_ address, char* hex_str);
	virtual Patch* __stdcall CreateCodePatchVA(_ptr_ address, char* format, _dword_* va_args);
	virtual LoHook* __stdcall CreateLoHook(_ptr_ address, void* func);
	virtual HiHook* __stdcall CreateHiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* new_func);
	
	virtual _bool_ __stdcall ApplyAll();
	virtual _bool_ __stdcall UndoAll();
	virtual _bool_ __stdcall DestroyAll();

	//ver 1.3
	virtual Patch* __stdcall WriteDataPatchVA(_ptr_ address, char* format, _dword_* va_args);
	virtual Patch* __stdcall CreateDataPatchVA(_ptr_ address, char* format, _dword_* va_args);
	virtual Patch* __stdcall GetLastPatchAt(_ptr_ address);
	virtual _bool_ __stdcall UndoAllAt(_ptr_ address);
	virtual Patch* __stdcall GetFirstPatchAt(_ptr_ address);

	//ver 1.6
	virtual Patch* __stdcall Write(_ptr_ address, _ptr_ data, _dword_ size, _bool_ is_code = 0);
	virtual Patch* __stdcall CreatePatch(_ptr_ address, _ptr_ data, _dword_ size, _bool_ is_code = 0);

	//ver 2.1
	virtual LoHook* __stdcall WriteLoHookEx(_ptr_ address, void* func, _dword_ stack_delta);
	virtual LoHook* __stdcall CreateLoHookEx(_ptr_ address, void* func, _dword_ stack_delta);

	virtual HexHook* __stdcall WriteHexHookVA(_ptr_ address, _bool_ exec_default, char* hex_str, _dword_* va_args);
	virtual HexHook* __stdcall CreateHexHookVA(_ptr_ address, _bool_ exec_default, char* hex_str, _dword_* va_args);

	virtual void __stdcall BlockAt(_ptr_ address);

public:
	char* name;
	HMODULE hmodule;
	_PointerList_<Patch> patches;
	_Array_<_ptr_, 4*10> blocks;

	PatcherInstance(HMODULE hmodule, char* name);
	~PatcherInstance();
};


NOALIGN struct LogRecord
{
	PatcherInstance* owner;
	_ptr_ address;
	_word_ size;
	_byte_ type : 2;
	_byte_ action : 6;
	_dword_ custom_data;
	LogRecord(_byte_ act, Patch* p)
	{
		owner	= p->parent;
		address = p->address;
		size	= p->size;
		type	= p->GetType();
		action	= act;
	}
	LogRecord(_byte_ act, Patch* p, _dword_ some_data)
	{
		owner	= p->parent;
		address = p->address;
		size	= p->size;
		type	= p->GetType();
		action	= act;
		custom_data = some_data;
	}
	LogRecord(_byte_ act, PatcherInstance* own, _ptr_ adr, _word_ siz, _byte_ typ)
	{
		owner	= own;
		address = adr;
		size	= siz;
		type	= typ;
		action	= act;
	}
	LogRecord(_byte_ act, PatcherInstance* own, _ptr_ adr, _word_ siz, _byte_ typ, _dword_ dat)
	{
		owner	= own;
		address = adr;
		size	= siz;
		type	= typ;
		action	= act;
		custom_data = dat;
	}
};

NOALIGN class Patcher
{
public:
	// ver 1.0:
	virtual PatcherInstance* __stdcall CreateInstance(char* name);
	virtual PatcherInstance*  __stdcall GetInstance(char* name);
	virtual Patch* __stdcall GetLastPatchAt(_ptr_ address);
	virtual _bool_ __stdcall UndoAllAt(_ptr_ address);
	virtual void __stdcall SaveDump(char* file_name);
	virtual void __stdcall SaveLog(char* file_name);
	virtual int __stdcall GetMaxPatchSize();
	
////////////////////////////////////////////////////////////////////
	virtual int __stdcall WriteComplexDataVA(_ptr_ address, char* format, _dword_* args);
	virtual int __stdcall GetOpcodeLength(_ptr_ p_opcode);
	virtual int __stdcall MemCopyCode(_ptr_ dst, _ptr_ src, _dword_ size);
////////////////////////////////////////////////////////////////////

	// ver 1.3
	virtual Patch* __stdcall GetFirstPatchAt(_ptr_ address);
	virtual int __stdcall MemCopyCodeEx(_ptr_ dst, _ptr_ src, _dword_ size);

	// ver 2.3
	virtual _Var_* __stdcall VarInit(char* name, _dword_ value);
	virtual _Var_* __stdcall VarFind(char* name);



public:
	PatchTree* patch_tree;
	_PointerList_<PatcherInstance>* instance_list;
	bool logging_on;
	HMODULE hmodule;
	Patcher();
	~Patcher();
};


__EXPORT Patcher* __stdcall GetPatcherX86();


// ���� ������������� ���� �������
// ���������� ����� ������ �� ������ p_opcode
int __cdecl _GetOpcodeLength(_byte_* p_opcode);

// ������������ ���� �������
// ���������� ����� �������, ������� ����������� ����� ������ need_length
int _GetNeedCodeLength(_byte_* p_code, int need_length);

int _WriteHexString(_ptr_ address, char* hex_string);
int _WriteCodeString(_ptr_ address, char* hex_string, ...);
int _WriteCodeStringVA(_ptr_ address, char* hex_string, _dword_* args, int* p_read_args_count = NULL, int pr = 0);
int _WriteDataString(_ptr_ address, char* hex_string, ...);
int _WriteDataStringVA(_ptr_ address, char* hex_string, _dword_* args, int* p_read_args_count = NULL, int pr = 0);

int __stdcall __MemCopyCode(_ptr_ dst, _ptr_ src, _dword_ size, _bool_ transform_short_jumps = 0);
int __stdcall __GetFuncReturnArgsCount(_ptr_ func);

#define GetFuncReturnAdress(func_first_var) (*(_ptr_*)(((_ptr_)&func_first_var) - 8))

void CalculateHookSize(Patch* hook);

HMODULE GetModuleHandleFromAddress(_ptr_ address);

void ShowErrMsg(char* pFormat, ...);

inline char* StrType(int type)
{
	switch (type)
	{
	case PATCH_:  return "Patch ";
	case LOHOOK_: return "LoHook";
	case HIHOOK_: return "HiHook";
	default: return "??????";
	}
};

void __stdcall Patch_SetRunningOff(Patch* patch);
void __stdcall Patch_SetRunningOn(Patch* patch);
