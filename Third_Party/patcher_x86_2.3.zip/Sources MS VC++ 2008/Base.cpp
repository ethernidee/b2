// /////////////////////////////////////////////////////////////////////////////////
// Author: Alexander Barinov (aka baratorch, aka Bara) e-mail: baratorch@yandex.ru
////////////////////////////////////////////////////////////////////////////////////

#include "Base.h"



char* GetShortFileName(char* filename)
{
	char* str_f = filename;
	char* str_r = NULL;

	for (int i = strlen(str_f) - 1; i >= 0; i--)
		if (str_f[i] == '\\')
		{
			str_r = str_f + i + 1;
			break;
		}

	if (!str_r) str_r = str_f;

	return str_r;
}