#include"_Patcher_x86_.h"
#include<string.h>

int show_errs =	TRUE;
_byte_ patch_buffer[MAX_PATCH_SIZE];
Patcher Px86 = Patcher();
_PointerList_<LogRecord> log = _PointerList_<LogRecord>();
_VarTree_ Vars = _VarTree_();

__EXPORT Patcher* __stdcall GetPatcherX86()
{
	return &Px86;
}


_ptr_ CodeAlloc(_dword_ size)
{
	_ptr_ r = MemAlloc(size);
	VirtualProtect((LPVOID)r, (SIZE_T)(size) , PAGE_EXECUTE_READWRITE, NULL);
	return r;
}
_ptr_ CodeAllocCopy(_dword_ size, _ptr_ src)
{
	_ptr_ r = CodeAlloc(size);
	__MemCopyCode(r, src, size);
	return r;
}


Patcher::~Patcher()
{
	//DeleteCriticalSection(&_cs);
}

Patcher::Patcher()
{
	//InitializeCriticalSection(&_cs);
	patch_tree = new PatchTree();
	instance_list = new _PointerList_<PatcherInstance>();
	logging_on = false;
	hmodule = GetModuleHandle("patcher_x86.dll");

	int v;
	int i;
	int ci;
	char digits[] = "01";
	FILE* fini = fopen("patcher_x86.ini", "r");
	if (fini)
	{
		while(true)
		{
			if ((ci = fgetc(fini)) == EOF) break;
			for (i = 0; i < 2; i++) if ((char)ci == digits[i]) {fseek(fini, -1, SEEK_CUR); break;}
			if (i < 2) break;
		}
		if (fscanf_s(fini, "%d", &v) != EOF)
			logging_on = (bool)min(1, max(0, v));
		fclose(fini);
	}
}





PatcherInstance* Patcher::CreateInstance(char* name)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(name));

	char module_name[MAX_PATH];
	if (hm)
	{
		if (GetModuleFileName(hm, module_name, MAX_PATH) == 0)
			module_name[0] = 0;
	}
	else
		module_name[0] = 0;

	if (name)
	{
		if (name[0] == 0) name = GetShortFileName(module_name);
	}
	else
	{
		name = GetShortFileName(module_name);
	}
	if (name[0] == 0) return NULL;

	for (_PointerListNode_<PatcherInstance>* node = instance_list->first; node != NULL; node = node->next)
	{
		if ( /*(node->p_item->hmodule == hm) && */(_stricmp(name, node->p_item->name) == 0) )
		{
			ShowErrMsg("'%s' instance created already!", name);
			return NULL;
		}
	}

	PatcherInstance* p = new PatcherInstance(hm, name);
	instance_list->Add(p);
	return p;
}

PatcherInstance* Patcher::GetInstance(char* name)
{
	if (!name) return NULL;
	char module_name[MAX_PATH];
	for (_PointerListNode_<PatcherInstance>* node = instance_list->first; node != NULL; node = node->next)
	{
		if (_stricmp(name, node->p_item->name) == 0)
			return node->p_item;
		if (GetModuleFileName(node->p_item->hmodule, module_name, MAX_PATH))
			if (_stricmp(name, GetShortFileName(module_name)) == 0)
				return node->p_item;
	}
	return NULL;
}

int Patcher::GetOpcodeLength(_ptr_ p_opcode)
{
	int r = 0;
	__asm push esi
	r = _GetOpcodeLength((_byte_*)p_opcode);
	__asm pop esi
	return r;
}

int Patcher::GetMaxPatchSize()
{
	return MAX_PATCH_SIZE;
}

Patch* Patcher::GetLastPatchAt(_ptr_ address)
{
	PatchNode* node = patch_tree->Find(address);
	if (node)
	{
		return node->patches[node->patches.Count() - 1];
	}
	else
	{
		return NULL;
	}
}
Patch* Patcher::GetFirstPatchAt(_ptr_ address)
{
	PatchNode* node = patch_tree->Find(address);
	if (node)
	{
		return node->patches[0];
	}
	else
	{
		return NULL;
	}
}

_bool_ Patcher::UndoAllAt(_ptr_ address)
{
	_bool_ result = 1;
	Patch* p = GetLastPatchAt(address);
	while(true)
	{
		if (p == NULL) break;
		Patch* before_applied = p->GetAppliedBefore();
		result &= (p->Undo() != -1);
		p = before_applied;
	}
	return result;
}

Patch* PatcherInstance::GetLastPatchAt(_ptr_ address)
{
	PatchNode* node = Px86.patch_tree->Find(address);
	if (node)
	{
		for (int i = node->patches.Count() - 1; i >= 0; i--)
			if (node->patches[i]->parent == this)
				return node->patches[i];
	}
	return NULL;
}
Patch* PatcherInstance::GetFirstPatchAt(_ptr_ address)
{
	PatchNode* node = Px86.patch_tree->Find(address);
	if (node)
	{
		for (int i = 0; i < node->patches.Count(); i++)
			if (node->patches[i]->parent == this)
				return node->patches[i];
	}
	return NULL;
}

_bool_ PatcherInstance::UndoAllAt(_ptr_ address)
{
	_bool_ result = 1;
	Patch* p = Px86.GetLastPatchAt(address);
	while(true)
	{
		if (p == NULL) break;
		Patch* before_applied = p->GetAppliedBefore();
		if (p->parent == this)
			result &= (p->Undo() != -1);
		p = before_applied;
	}
	return result;
}


int Patcher::MemCopyCode(_ptr_ dst, _ptr_ src, _dword_ size)
{
	return __MemCopyCode(dst, src, size);
}
int Patcher::MemCopyCodeEx(_ptr_ dst, _ptr_ src, _dword_ size)
{
	return __MemCopyCode(dst, src, size, TRUE);
}

void WriteVarsDump(FILE* f)
{
	fprintf(f, "variables(%d):\r\n\r\n", Vars.count);

	_Var_* it = Vars.root;
	_Array_<_Var_*,4000> up;
	up.SetLength(50);

	int top = 0;

	while (it != NULL)
	{
		while (it != NULL)
		{
			if (it->link[1] != NULL) up[top++] = it->link[1];
			up[top++] = it;
			it = it->link [0];
		}

		it = up[--top];

		while ((top != 0) && (it->link [1] == NULL))
		{
			fprintf(f, "\"%s\" = %d ( 0x%.8X )", it->name, it->value, it->value);
			fprintf(f, "\r\n");
			it = up[--top];
		}

		fprintf(f, "\"%s\" = %d ( 0x%.8X )", it->name, it->value, it->value);
		fprintf(f, "\r\n");

		if (top == 0) break;

		it = up[--top];
	}
}

void Patcher::SaveDump(char* file_name)
{
	FILE* f = fopen(file_name, "w+");
	fprintf(f, "instances(%d):", instance_list->count);
	for (_PointerListNode_<PatcherInstance>* node = instance_list->first; node != NULL; node = node->next)
	{
		fprintf(f, " '%s',", node->p_item->name);
	}
	fprintf(f, "\r\n");

	fprintf(f, "addresses count: %d\r\n", patch_tree->count);
	fprintf(f, "  patches count: %d\r\n\r\n", patch_tree->patches_count);

	PatchNode* it = patch_tree->root;
	_Array_<PatchNode*,4000> up;
	up.SetLength(50);

	int top = 0;

	while (it != NULL)
	{
		while (it != NULL)
		{
			if (it->link[1] != NULL) up[top++] = it->link[1];
			up[top++] = it;
			it = it->link [0];
		}

		it = up[--top];

		while ((top != 0) && (it->link [1] == NULL))
		{
			fprintf(f, "%.8X: count = %d", it->patches[0]->address, it->patches.length);
			for (int i = 0; i < it->patches.length; i++)
			{
				if (it->patches[i]->flags & PF_FIXED)
					fprintf(f, "\t<%s, size: %.2d, owner: %s, FIXED>", StrType(it->patches[i]->GetType()), it->patches[i]->size, it->patches[i]->GetOwner());
				else
					fprintf(f, "\t[%s, size: %.2d, owner: %s]", StrType(it->patches[i]->GetType()), it->patches[i]->size, it->patches[i]->GetOwner());
			}
			fprintf(f, "\r\n");
			it = up[--top];
		}

		fprintf(f, "%.8X: count = %d", it->patches[0]->address, it->patches.length);
		for (int i = 0; i < it->patches.length; i++)
		{
			if (it->patches[i]->flags & PF_FIXED)
				fprintf(f, "\t<%s, size: %.2d, owner: %s, FIXED>", StrType(it->patches[i]->GetType()), it->patches[i]->size, it->patches[i]->GetOwner());
			else
				fprintf(f, "\t[%s, size: %.2d, owner: %s]", StrType(it->patches[i]->GetType()), it->patches[i]->size, it->patches[i]->GetOwner());
		}
		fprintf(f, "\r\n");

		if (top == 0) break;

		it = up[--top];
	}

	fprintf(f, "\r\n\r\n\r\n\r\n");
	WriteVarsDump(f);

	fclose(f);
}

enum 
{ 
	LM_APPLY,
	LM_APPLY_INSERT,
	LM_UNDO,
	LM_UNDO_ALREADY,
	LM_UNDO_FIXED,
	LM_DESTROY,
	LM_DESTROY_FAIL,
	LM_WRN_SIZE,
	LM_WRN_TYPE,
	LM_WRN_SHIFT,
	LM_ERR_CALL_,
	LM_ERR_GETDEFAULT,
	LM_ERR_GETORIGINAL,
	LM_ERR_INSTANCE,
};

void Patcher::SaveLog(char* file_name)
{
	FILE* f = fopen(file_name, "w+");
	fprintf(f, "log records count: %d\r\n\r\n", log.count);
	LogRecord *p, *p2;
	for (_PointerListNode_<LogRecord>* node = log.first; node != NULL; node = node->next)
	{
		p = node->p_item;
		p2 = node->next ? node->next->p_item : p;
		switch(p->action)
		{
		case LM_APPLY:
			fprintf(f, "%s\t%.8X/%.2d ->Apply       (%s), z-order = %d\r\n", StrType(p->type), p->address, p->size, p->owner->name, p->custom_data);
			break;
		case LM_APPLY_INSERT:
			fprintf(f, "%s\t%.8X/%.2d ->ApplyInsert (%s), z-order = %d\r\n", StrType(p->type), p->address, p->size, p->owner->name, p->custom_data);
			break;
		case LM_UNDO_ALREADY:
			fprintf(f, "%s\t%.8X/%.2d ->Try Undo    (%s): %s is not applied! Cann't undo.\r\n", StrType(p->type), p->address, p->size, p->owner->name, StrType(p->type));
			break;
		case LM_UNDO:
			fprintf(f, "%s\t%.8X/%.2d ->Undo        (%s)\r\n", StrType(p->type), p->address, p->size, p->owner->name);
			break;
		case LM_DESTROY:
			fprintf(f, "%s\t%.8X/%.2d ->Destroy     (%s)\r\n", StrType(p->type), p->address, p->size, p->owner->name);
			break;
		case LM_WRN_SIZE:
			fprintf(f, "\r\nWARNING! %.8X: Applying %s (size: %d, owner: %s), which overwrites already applied %s (size: %d, owner: %s). Different sizes!\r\n\r\n",
				p->address,  StrType(p->type), p->size, p->owner->name, StrType(p2->type), p2->size, p2->owner->name);
			node = node->next;
			break;
		case LM_WRN_TYPE:
			fprintf(f, "\r\nWARNING! %.8X: Applying %s (size: %d, owner: %s), which overwrites already applied %s (size: %d, owner: %s).\r\n\r\n",
				p->address,  StrType(p->type), p->size, p->owner->name, StrType(p2->type), p2->size, p2->owner->name);
			node = node->next;
			break;
		case LM_WRN_SHIFT:
			fprintf(f, "\r\nWARNING! %.8X: Applying %s (size: %d, owner: %s), which overwrites a part of already applied %s (size: %d, owner: %s) at %.8X! Older one becomes FIXED!\r\n\r\n",
				p->address, StrType(p->type), p->size, p->owner->name, StrType(p2->type), p2->size, p2->owner->name, p2->address);
			node = node->next;
			break;
		case LM_ERR_CALL_:
			fprintf(f, "\r\nERROR!   %.8X: can not apply CALL_ HiHook! (owner: %s) Wrong opcode: %.2X %.2X ...!\r\n\r\n", 
				p->address, p->owner->name,  *(_byte_*)((_ptr_)&p->size), *(_byte_*)((_ptr_)&p->size + 1));
			break;
		case LM_UNDO_FIXED:
			fprintf(f, "%s\t%.8X/%.2d ->Try Undo (%s): Patch is FIXED! Cannot Undo!\r\n",
				StrType(p->type), p->address, p->size, p->owner->name);
			break;
		
		case LM_ERR_INSTANCE:
			fprintf(f, "%s\tERROR!   Can not create %s at %.8X (%s): Wrong Patcher Instance!\r\n",
				StrType(p->type), p->address, p->owner->name);
			break;
		}
	}
	fclose(f);
}

int Patcher::WriteComplexDataVA(_ptr_ address, char* format, _dword_* args)
{
	return _WriteCodeStringVA(address, format, args);
}



_ptr_ Patch::GetAddress()
{
	return address;
}
_ptr_ LoHook::GetAddress()
{
	return Patch::GetAddress();
}
_ptr_ HexHook::GetAddress()
{
	return Patch::GetAddress();
}
_ptr_ HiHook::GetAddress()
{
	return Patch::GetAddress();
}


_dword_	Patch::GetSize()
{
	return size;
}
_dword_	LoHook::GetSize()
{
	return Patch::GetSize();
}
_dword_	HexHook::GetSize()
{
	return Patch::GetSize();
}
_dword_	HiHook::GetSize()
{
	return Patch::GetSize();
}

char* Patch::GetOwner()
{
	return parent->name;
}
char* LoHook::GetOwner()
{
	return Patch::GetOwner();
}
char* HexHook::GetOwner()
{
	return Patch::GetOwner();
}
char* HiHook::GetOwner()
{
	return Patch::GetOwner();
}

int Patch::GetType()
{
	return ((flags & PF_LOHOOK) != 0) + 2*((flags & PF_HIHOOK) != 0);
}
int LoHook::GetType()
{
	return Patch::GetType();
}
int HexHook::GetType()
{
	return Patch::GetType();
}
int HiHook::GetType()
{
	return Patch::GetType();
}



_bool_ Patch::IsApplied()
{
	return (flags & PF_APPLIED);
}
_bool_ LoHook::IsApplied()
{
	return Patch::IsApplied();
}
_bool_ HexHook::IsApplied()
{
	return Patch::IsApplied();
}
_bool_ HiHook::IsApplied()
{
	return Patch::IsApplied();
}
_bool_ Patch::Apply()
{
	DWORD protect;

	for (int b = this->parent->blocks.length - 1; b >= 0; b--)
		if (address == this->parent->blocks[b])
			return -1;

	if (IsApplied()) return -2;

	if (Px86.patch_tree->Add(this))
	{
		///
		//EnterCriticalSection(&_cs);
		VirtualProtect((LPVOID)address, (SIZE_T)size , PAGE_READWRITE, &protect);
		if (flags & PF_CODE)
		{
			__MemCopyCode(old_data, address, size, FALSE);
			__MemCopyCode(address, new_data, size, FALSE);
		}
		else
		{
			MemCopy(old_data, address, size);
			MemCopy(address, new_data, size);
		}
		VirtualProtect((LPVOID)address, (SIZE_T)size , protect, NULL);
		//LeaveCriticalSection(&_cs);
		///

		flags |= PF_APPLIED;

		if (Px86.logging_on) log.Add(new LogRecord(LM_APPLY, this, (_dword_)(this->node->patches.Count() - 1)));

		return this->node->patches.Count() - 1;
	}
	else
		return -1;
}
_bool_ LoHook::Apply()
{
	if (IsApplied()) return -2;

	CalculateHookSize(this);

	_WriteCodeString(tail_code, 
		"%m %%", address, size,						// exec default code
		"FF 25 %d %.", &return_address);

	return Patch::Apply();
}
_bool_ HiHook::Apply()
{
	if (IsApplied()) return -2;

	///
	//EnterCriticalSection(&_cs);
	if (subtype == SAFE_)
	{
		switch (hooktype)
		{
		case CALL_:
			if (*(_byte_*)address == 0xE8) // call n32 opcode
				_WriteCodeString(bridge_to_default,	"%j %.", PtrAt(address + 1) + address + 5);
			else if ( (ByteAt(address) == 0xFF) && (ByteAt(address+1) == 0x15) ) // call [n32] opcode
				_WriteCodeString(bridge_to_default,	"%j %.", PtrAt(PtrAt(address + 2))); 
			else
			{
				if (Px86.logging_on)
				{
					log.Add(new LogRecord(LM_ERR_CALL_, this));
					log.last->p_item->size = *(_word_*)address;
				}
				return 0;
			}
			break;

		case SPLICE_:
			MemSet(bridge_to_default, 0x90, 6 + 6 + 15 + 5);
			_WriteCodeString(bridge_to_default,
				"%m %%", address, size,
				"%j %.", address + size);
			break;

		case FUNCPTR_:
			_WriteCodeString(bridge_to_default,	"%j %.", DwordAt(address));
			break;
		}
	}
	else
	{
		switch (hooktype)
		{
		case CALL_:
			if (*(_byte_*)address == 0xE8) // call n32 opcode
				default_func = *(_ptr_*)(address + 1) + address + 5; 
			else if ( (*(_byte_*)address == 0xFF) && (*(_byte_*)(address+1) == 0x15) ) // call [n32] opcode
				default_func = *(_ptr_*)(*(_ptr_*)(address + 2)); 
			else
			{
				if (Px86.logging_on)
				{
					log.Add(new LogRecord(LM_ERR_CALL_, this));
					log.last->p_item->size = *(_word_*)address;
				}
				return 0;
			}
			break;

		case SPLICE_:
			//CalculateHookSize(this);
			_WriteCodeString(bridge_to_default,
				//"CD 03 %%",
				"%m %%", address, size,
				"%j %.", address + size);
			default_func = bridge_to_default;
			break;

		case FUNCPTR_:
			default_func = DwordAt(address);
			break;
		}
	}
	//LeaveCriticalSection(&_cs);
	///



	return Patch::Apply();
}

_bool_ Patch::ApplyInsert(int zorder)
{
	Patch* lp = Px86.GetLastPatchAt(address);

	if (lp == NULL) 
		return this->Apply();

	zorder = max(0, zorder);
	_Array_<Patch*, 4> unapplied_patches;
	unapplied_patches.SetLength(0);
	bool tmp_logging = Px86.logging_on;
	Px86.logging_on = false;

	if (zorder >= lp->node->patches.Count())
		return this->Apply();

	Patch* p;
	int ii = 0;
	while (true)
	{
		p = Px86.GetLastPatchAt(address);
		int ii = p->Undo();
		if (ii < 0) break;
		unapplied_patches.Add(p);
		if (ii == zorder) break;
	}
	_bool_ result = this->Apply();

	for (int i = unapplied_patches.Count() - 1; i >= 0; i--)
		unapplied_patches[i]->Apply();
	
	Px86.logging_on = tmp_logging;
	
	if (Px86.logging_on) log.Add(new LogRecord(LM_APPLY_INSERT, this, (_dword_)result));

	return result;
}
_bool_ LoHook::ApplyInsert(int zorder)
{
	return Patch::ApplyInsert(zorder);
}
_bool_ HexHook::ApplyInsert(int zorder)
{
	return Patch::ApplyInsert(zorder);
}
_bool_ HiHook::ApplyInsert(int zorder)
{
	return Patch::ApplyInsert(zorder);
}



int Patch::Undo()
{
	if (!IsApplied())
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_UNDO_ALREADY, this));
		return -2;
	}
	if (flags & PF_FIXED)
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_UNDO_FIXED, this));
		return -3;
	}

	_Array_<Patch*, 4> unapplied_patches;
	unapplied_patches.SetLength(0);
	bool tmp_logging = Px86.logging_on;
	Px86.logging_on = false;
	Patch* aa = this->GetAppliedAfter();
	if (aa) 
	{
		Patch* p;
		while (true)
		{
			p = Px86.GetLastPatchAt(address);
			p->Undo();
			unapplied_patches.Add(p);
			if (p == aa) break;
		}
	}

	DWORD protect;
	///
	//EnterCriticalSection(&_cs);
	VirtualProtect((LPVOID)address, (SIZE_T)size , PAGE_READWRITE, &protect);
	if (flags & PF_CODE)
		__MemCopyCode(address, this->old_data, size, FALSE);
	else
		MemCopy(address, this->old_data, size);
	VirtualProtect((LPVOID)address, (SIZE_T)size , protect, NULL);
	///
	//LeaveCriticalSection(&_cs);

	for (int i = unapplied_patches.Count() - 1; i >= 0; i--)
		unapplied_patches[i]->Apply();
	
	Px86.logging_on = tmp_logging;

	flags ^= PF_APPLIED;

	if (Px86.logging_on) log.Add(new LogRecord(LM_UNDO, this));

	return Px86.patch_tree->Remove(this);
}
int LoHook::Undo()
{
	return Patch::Undo();
}
int HexHook::Undo()
{
	return Patch::Undo();
}
int HiHook::Undo()
{	
	return Patch::Undo();
}

int Patch::Destroy()
{
	if (IsApplied()) return 0;

	if (Px86.logging_on) log.Add(new LogRecord(LM_DESTROY, this));
	parent->patches.Remove(this);
	switch (this->GetType())
	{
		case PATCH_ : delete ((Patch*)this); break;
		case LOHOOK_: delete ((LoHook*)this); break;
		case HIHOOK_: delete ((HiHook*)this); break;
	}

	return 1;
}


int LoHook::Destroy()
{
	return Patch::Destroy();
}
int HexHook::Destroy()
{
	return Patch::Destroy();
}
int HiHook::Destroy()
{
	return Patch::Destroy();
}

_ptr_ HiHook::GetDefaultFunc()
{
	return default_func;
}
_ptr_ HiHook::GetOriginalFunc()
{
	Patch* la = Px86.GetLastPatchAt(address);
	Patch* fa = NULL;
	if (la) fa = la->node->patches[0];
	for (Patch* p = fa; p != NULL; p = p->GetAppliedAfter())
		if (p->GetType() == HIHOOK_)
			return ((HiHook*)p)->default_func;

	return default_func;
}


_bool_ PatcherInstance::ApplyAll()
{
	_bool_ result = TRUE;
	for (_PointerListNode_<Patch>* node = patches.first; node != NULL; node = node->next)
		result &= (node->p_item->Apply() != -1);
	return result;
}

_bool_ PatcherInstance::UndoAll()
{
	_bool_ result = TRUE;
	for (_PointerListNode_<Patch>* node = patches.first; node != NULL; node = node->next)
		result &= (node->p_item->Undo() != -1);
	return result;
}
_bool_ PatcherInstance::DestroyAll()
{
	_bool_ result = TRUE;
	for (_PointerListNode_<Patch>* node = patches.first; node != NULL; node = node->next)
		result &= (node->p_item->Destroy() != -1);
	return result;
}


PatcherInstance::PatcherInstance(HMODULE hm, char* name)
{
	int sz = strlen(name) + 1;
	this->name = (char*)MemAlloc(sz);
	MemCopy(this->name, name, sz);
	this->hmodule = hm;
	this->blocks.SetLength(0);
}


PatchNode::PatchNode()
{
	this->balance = 0;
	this->link[0] = this->link[1] = NULL;
}
PatchNode::~PatchNode()
{
}

PatchTree::PatchTree()
{
	this->root = NULL;
	this->count = 0;
	this->patches_count = 0;
}

int PatchTree::Add(Patch *patch)
{
	PatchNode ** v, *w, *x, *y, *z;
	Patch* last_applied;

 //���� � ������ ��� ��� ����� 
	v = &root;
	x = /*node*/z = root;
	if(x == NULL)
	{
		root = new PatchNode();
		root->patches.Add(patch);
		patch->node = root;
		patches_count++;
		count++;
		return root != NULL;
	}

 //����� ���������� ������� � ����������� ������� �������� 
	while(true)
	{
		int dir;
		last_applied = z->patches[z->patches.length - 1];

		 //����� ������� ��� ���� � ������
		if(patch->address == last_applied->address)
		{
			if (patch->size != last_applied->size)
			{
				if (patch->GetType() == last_applied->GetType())
				{
					if (Px86.logging_on) log.Add(new LogRecord(LM_WRN_SIZE, patch));
					if (Px86.logging_on) log.Add(new LogRecord(0, last_applied));
				}
			}

			if (patch->GetType() != last_applied->GetType())
			{
				if (Px86.logging_on) log.Add(new LogRecord(LM_WRN_TYPE, patch));
				if (Px86.logging_on) log.Add(new LogRecord(0, last_applied));
			}

			z->patches.Add(patch);
			patch->node = z;
			patches_count++;
			return 1;
		}

		//dir = (patch->address > last_applied->address) ;
		if (patch->address > last_applied->address)
		{
			if ( patch->address < (last_applied->address + last_applied->size) )
			{
				if (Px86.logging_on) log.Add(new LogRecord(LM_WRN_SHIFT, patch));
				if (Px86.logging_on) log.Add(new LogRecord(0, last_applied));
				for (int ix = 0; ix < z->patches.Count(); ix++)
					z->patches[ix]->flags |= PF_FIXED;
			}
			dir = 1;
		}
		else
		{
			if ((patch->address + patch->size) > last_applied->address)
			{
				if (Px86.logging_on) log.Add(new LogRecord(LM_WRN_SHIFT, patch));
				if (Px86.logging_on) log.Add(new LogRecord(0, last_applied));
				for (int ix = 0; ix < z->patches.Count(); ix++)
					z->patches[ix]->flags |= PF_FIXED;
			}
			dir = 0;
		}

		/*node_link_x*/y = /*node*/z->link[dir];

		if(/*node_link_x*/y == NULL)
		{
			/*node_link_x*/y = /*node*/z->link[dir] = new PatchNode();
			if(y == NULL) return 0;
			y->patches.Add(patch);
			patch->node = y;
			patches_count++;
			count++;
			break;
		}

		if(/*node_link_x*/y->balance != 0)
		{
			v = /*node*/&z->link[dir];
			/*unbalansed node*/x = /*node_link_x*/y;
		}
		/*node*/z = /*node_link_x*/y;
	}

 //�������� ������������� ������������������ ��� �����, ���������� �������� 
	w = /*node*/z = /*unbalansed node*/x->link[patch->address > /*unbalansed node*/x->patches[0]->address];
	while(/*node*/z != /*new added node*/y)
		if(patch->address < /*node*/z->patches[0]->address)
		{
			/*node*/z->balance = -1;
			/*node*/z = /*node*/z->link[0];
		}
		else
		{
			/*node*/z->balance	=	+1;
			/*node*/z = /*node*/z->link[1];
		}

 //������������ ��� ���������� ������ ���� � ����� ��������� 
	if(patch->address < /*unbalansed node*/x->patches[0]->address)
	{
		if (/*unbalansed node*/x->balance != -1)
			/*unbalansed node*/x->balance --;
		else if(w->balance == -1)
		{
			*v=w;
			/*unbalansed node*/x->link[0] = w->link[1];
			w->link[1] = /*unbalansed node*/x;
			x->balance = w->balance = 0;
		}
		else
		{
			*v = z = w->link[1];
			w->link[1] = z->link[0];
			z->link[0] = w;
			x->link[0] = z->link[1];
			z->link[1] = x;
			if(z->balance == -1)
			{
				x->balance = 1;
				w->balance = 0;
			}			
			else if(z->balance == 0)
				x->balance = w->balance = 0;
			else
			{
				x->balance = 0;
				w->balance = -1;
			}
			z->balance=0;
		}
	}
 //������������ ��� ���������� ������ ���� � ������ ��������� 
	else 
	{
		if( x->balance != +1)
			x->balance++;
		else if(w->balance == +1)
		{
			*v = w;
			x->link[1] = w->link[0];
			w->link[0] = x;
			x->balance = w->balance = 0;	
		}
		else
		{
			*v = z = w->link[0];
			w->link[0] = z->link[1];
			z->link[1] = w;
			x->link[1] = z->link[0];
			z->link[0] = x;
			if(z->balance == +1)
			{
				x->balance = -1;
				w->balance = 0;			
			}
			else if(z->balance == 0)
				x->balance = w->balance = 0;
			else
			{
				x->balance = 0;
				w->balance = 1;
			}
			z->balance = 0;
		}
	}
	return 1;
}

_Array_<PatchNode*,32*4> ap;
_Array_<int, 32*4> ad;
int PatchTree::Remove(Patch *patch)
{
	int result = -1;
	ap.SetLength(1);
	ad.SetLength(1);
	int k = 1;

	PatchNode ** y, * z;

	ad[0] = 0 ;
	ap[0] = (PatchNode* ) &root;

	z = root;

 //����� ����, ���������� ��� �������� 
	while(true)
	{
		int dir;
		if(z == NULL)
			return -1 ;
		if (patch->address == z->patches[0]->address)
			break;

		dir = patch->address > z->patches[0]->address;
		ap[k] = z;
		ad[k++] = dir;
		z = z->link[dir];
	}

	result = z->patches.Remove(patch);
	patches_count--;
	patch->node = NULL;
	if (z->patches.length != 0) return result;

 //����������� �������� ���� �� ������ 
	count-- ;
	y = &ap[k - 1]->link[ad[k-1]];
	if(z->link[1] == NULL)
		*y = z->link[0];
	else
	{ 
		struct PatchNode *x = z->link[1];
		if (x->link[0] == NULL)
		{
			x->link[0] = z->link[0];
			*y = x;
			x->balance = z->balance;
			ad[k] = 1;
			ap[k++] = x;
		}
		else
		{
			struct PatchNode *w = x->link[0];
			int j = k++;
			ad[k] = 0 ;
			ap[k++] = x;
			while (w->link[0] != NULL)
			{
				x = w;
				w = x->link[0];
				ad[k] = 0 ;
				ap[k++] = x;
			}
			
			ad[j] = 1;
			ap[j] = w;
			w->link[0] = z->link[0];
			x->link[0] = w->link[1];
			w->link[1] = z->link[1];
			w->balance = z->balance;
			*y = w;
		}
	}
	delete z;

 //������������ ������������� ������ 
	while(--k)
	{
		struct PatchNode *w, *x;
		w = ap[k];	
		if (ad[k] == 0 )
		{
			if (w->balance == -1)
			{
				w->balance = 0;
				continue;
			}
			else if (w->balance == 0 )
			{
				w->balance = 1;
				break;
			}
			
			x = w->link[1];
			if (x->balance > -1)
			{
				w->link[1]= x->link[0];
				x->link[0] = w;
				ap[k-1]->link[ad[k-1]] = x;
				if (x->balance == 0 )
				{
					x->balance = -1;
					break;
				}
				else
					w->balance = x->balance = 0 ;
			}
			else
			{
				z = x->link[0];
				x->link[0] = z->link[1];
				z->link[1] = x;
				w->link[1] = z->link[0];
				z->link[0] = w;
				if (z->balance == 1)
				{
					w->balance = -1;
					x->balance = 0;
				}
				else if (z->balance == 0 )
					w->balance = x->balance = 0;
				else
				{
					w->balance = 0;
					x->balance = 1;
				}
				z->balance = 0;
				ap[k-1]->link[ad[k-1]] = z;
			}
		}
		else
		{
			if (w->balance == 1)
			{
				w->balance = 0 ;
				continue;
			}
			else if (w->balance ==0)
			{
				w->balance = -1;
				break;
			}

			x = w->link[0];
			if (x->balance < 1)
			{
				w->link[0] = x->link[1];
				x->link[1] = w;
				ap[k-1]->link[ad[k-1]] = x;
				if (x->balance == 0 )
				{
					x->balance = 1;
					break;
				}
				else
					w->balance = x->balance = 0;
			}
			else if (x->balance == 1)
			{
				z = x->link[1];
				x->link[1] = z->link[0];
				z->link[0] = x;
				w->link[0] = z->link[1];
				z->link[1] = w;
				if (z->balance == -1)
				{
					w->balance = 1;
					x->balance = 0;
				}
				else if (z->balance == 0 )
					w->balance = x->balance = 0;
				else
				{
					w->balance = 0;
					x->balance = -1;
				}
				z->balance = 0;
				ap[k-1]->link[ad[k-1]] = z;
			}
		}
	}
	return 0;
}



PatchNode* PatchTree::Find(_ptr_ address)
{
	PatchNode *y, *z;

	 //���� � ������ ��� ��� ����� 
	/*node*/z = root;
	if(z == NULL)
		return NULL;

	while(true)
	{
		 //����� ������� ���� � ������ � ������� ����� ��������� 
		if(address == /*node*/z->patches[0]->address)
			return z;

		/*node_link_x*/y = /*node*/z->link[address > /*node*/z->patches[0]->address];

		if(/*node_link_x*/y == NULL)
			return NULL;

		/*node*/z = /*node_link_x*/y;
	}
}






Patch* Patch::GetAppliedBefore()
{
	int applied_before_i = -1;
	if (IsApplied())
	{
		for (int i = 0; i < this->node->patches.length; i++)
		{
			if (this->node->patches[i] == this)
			{
				applied_before_i = i - 1;
				break;
			}
		}
	}
	if (applied_before_i > -1) 
		return this->node->patches[applied_before_i];
	else
		return NULL;
}
Patch* LoHook::GetAppliedBefore()
{
	return Patch::GetAppliedBefore();
}
Patch* HexHook::GetAppliedBefore()
{
	return Patch::GetAppliedBefore();
}
Patch* HiHook::GetAppliedBefore()
{
	return Patch::GetAppliedBefore();
}

Patch* Patch::GetAppliedAfter()
{
	int applied_after_i = this->node->patches.length;
	if (IsApplied())
	{
		for (int i = 0; i < this->node->patches.length; i++)
		{
			if (this->node->patches[i] == this)
			{
				applied_after_i = i + 1;
				break;
			}
		}
	}
	if (applied_after_i < this->node->patches.length) 
		return this->node->patches[applied_after_i];
	else
		return NULL;
}
Patch* LoHook::GetAppliedAfter()
{
	return Patch::GetAppliedAfter();
}
Patch* HexHook::GetAppliedAfter()
{
	return Patch::GetAppliedAfter();
}
Patch* HiHook::GetAppliedAfter()
{
	return Patch::GetAppliedAfter();
}

_ptr_ HiHook::GetReturnAddress()
{
	return this->return_address;
}

void HiHook::SetUserData(_dword_ data)
{
	this->user_data = data;
}

_dword_ HiHook::GetUserData()
{
	return this->user_data;
}


Patch::Patch(_ptr_ address, _ptr_ new_data, _word_ size, _bool_ is_code)
{
	this->address  = address;
	this->new_data = MemAlloc(size);
	this->old_data = MemAlloc(size);
	this->flags = (is_code != 0)*PF_CODE;
	if (is_code)
		__MemCopyCode(this->new_data, new_data, size);
	else
		MemCopy(this->new_data, new_data, size);
	this->size = size;
	this->parent = NULL;
	this->node = NULL;
}

Patch::~Patch()
{
	MemFree(new_data);
	MemFree(old_data);
}


Patch* PatcherInstance::CreatePatch(_ptr_ address, _ptr_ data, _dword_ size, _bool_ is_code)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}

	Patch* patch = new Patch(address, data, size, is_code);
	patch->parent = this;
	patches.Add(patch);
	return patch;
}
Patch* PatcherInstance::Write(_ptr_ address, _ptr_ data, _dword_ size, _bool_ is_code)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}

	Patch* patch = CreatePatch(address, data, size, is_code);
	patch->Apply();
	return patch;
}

Patch* PatcherInstance::CreateBytePatch(_ptr_ address, int value)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	return CreatePatch(address, (_ptr_)&value, 1);
}
Patch* PatcherInstance::CreateWordPatch(_ptr_ address, int value)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	return CreatePatch(address, (_ptr_)&value, 2);
}
Patch* PatcherInstance::CreateDwordPatch(_ptr_ address, int value)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	return CreatePatch(address, (_ptr_)&value, 4);
}


Patch* PatcherInstance::WriteByte(_ptr_ address, int value)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	return Write(address, (_ptr_)&value, 1);
}
Patch* PatcherInstance::WriteWord(_ptr_ address, int value)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	return Write(address, (_ptr_)&value, 2);
}
Patch* PatcherInstance::WriteDword(_ptr_ address, int value)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	return Write(address, (_ptr_)&value, 4);
}

Patch* PatcherInstance::CreateJmpPatch(_ptr_ address, _ptr_ to)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	int sz = _GetNeedCodeLength((_byte_*)address, 5);
	if (!sz) sz = 5;
	while(ByteAt(address + sz) == 0x90) sz++;
	MemSet(patch_buffer, 0x90, sz);
	SetJmpAt(patch_buffer, to);
	return Write(address, (_ptr_)patch_buffer, sz, TRUE);
}
Patch* PatcherInstance::WriteJmp(_ptr_ address, _ptr_ to)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	Patch* patch = CreateJmpPatch(address, to);
	patch->Apply();
	return patch;
}


int _WriteHexString(_ptr_ address, char* hex_string)
{
	if (!hex_string) return 0;
	int r = 0;

    BOOL have_first_digit = FALSE;
	int n = 0;
	char* digits = "0123456789ABCDEF";

	for (int i = 0; hex_string[i] != 0; i++)
	{
		if (hex_string[i] == ' ') continue;

		for (int d = 0; d < 16; d++)
		{
			if (hex_string[i] == digits[d])
			{
				if (have_first_digit)
				{
					n += d;
					SetByteAt(address + r, n);
					r++;
					have_first_digit = FALSE;
				}
				else
				{
					n = (d << 4);
					have_first_digit = TRUE;
				}
				break;
			}
		}
	}
	return r;
}

struct DataWriter
{
	_dword_					address;
	int						offset;
	_ptr_					p_arg;

	DataWriter(_ptr_ address, _dword_* args);
	void Process(char* format_str);
};
struct CodeWriter
{
	_dword_					address;
	int						offset;
	_ptr_					p_arg;
	_Array_<_dword_, 44>	goto_to;
	_Array_<_byte_, 44>		label;
	_Array_<_dword_, 44>	goto_from;

	CodeWriter(_ptr_ address, _dword_* args);
	void Process(char* format_str);
};

DataWriter::DataWriter(_ptr_ addr, _dword_* args)
{
	this->address = addr;
	this->offset = 0;
	this->p_arg = (_ptr_)args;
}
CodeWriter::CodeWriter(_ptr_ addr, _dword_* args)
{
	this->address = addr;
	this->offset = 0;
	this->p_arg = (_ptr_)args;
	this->goto_to.SetLength(10);
	this->label.SetLength(0);
	this->goto_from.SetLength(0);
}

void DataWriter::Process(char* format_str)
{
static char* digits = "0123456789ABCDEF";

	BOOL have_first_digit = FALSE;
	int n = 0;

	for (int i = 0; format_str[i] != 0; i++)
	{
		if (format_str[i] == ' ') continue;

		if (format_str[i] == '%')
		{
			switch (format_str[i+1])
			{
				case 0:
					i++;
					break;

				case 'h':
				case '%':
					p_arg += 4;
					Process(CStrAt(p_arg - 4));
					i++;
					break;

				case 'd':
					SetDwordAt(address + offset, IntAt(p_arg));
					offset += 4;
					p_arg += 4;
					i++;
					break;

				case 'w':
					SetWordAt(address + offset, IntAt(p_arg));
					offset += 2;
					p_arg += 4;
					i++;
					break;

				case 'b':    
					SetByteAt(address + offset, IntAt(p_arg));
					offset += 1;
					p_arg += 4;
					i++;
					break;
				
				case 'm': 
					MemCopy(address + offset, PtrAt(p_arg), PtrAt(p_arg + 4));
					offset += PtrAt(p_arg + 4);
					p_arg += 8;
					i++;
					break;

				case 's':
					if (PtrAt(p_arg)) 
					{
						MemCopy(address + offset, PtrAt(p_arg), strlen((char*)PtrAt(p_arg))+1);
						offset += strlen((char*)PtrAt(p_arg))+1;
					}
					p_arg += 4;
					i++;
					break;

				case 'a': 
					PtrAt(PtrAt(p_arg)) = address + offset;
					p_arg += 4;
					i++;
					break;

				case 'o': 
					PtrAt(PtrAt(p_arg)) = offset;
					p_arg += 4;
					i++;
					break;

				case '.': 
					i++;
					break;

				default: 
					i++;
			}
			continue;
		}

		for (int d = 0; d < 16; d++)
		{
			if (format_str[i] == digits[d])
			{
				if (have_first_digit)
				{
					n += d;
					SetByteAt(address + offset, n);
					offset++;
					have_first_digit = FALSE;
				}
				else
				{
					n = (d << 4);
					have_first_digit = TRUE;
				}
				break;
			}
		}
	}

}

void CodeWriter::Process(char* format_str)
{
static char* digits = "0123456789ABCDEF";

	BOOL have_first_digit = FALSE;
	int n = 0;

	for (int i = 0; format_str[i] != 0; i++)
	{
		if (format_str[i] == ' ') continue;

		if (format_str[i] == '~')
		{
			if (format_str[i+1] == 'b')
			{
				ByteAt(address + offset) = (_byte_)(char)(int)(DwordAt(p_arg) - (address + offset) - 1);
				p_arg += 4;
				offset += 1;
				i+=2;
				continue;
			}
			else if (format_str[i+1] == 'd')
			{
				DwordAt(address + offset) = DwordAt(p_arg) - (address + offset) - 4;
				p_arg += 4;
				offset += 4;
				i+=2;
				continue;
			}
			else
				continue;
		}

		if (format_str[i] == '#')
		{
			if ( (format_str[i+1] >= '0') && (format_str[i+1] <= '9'))
			{
				if (format_str[i+2] == ':')
				{
					goto_to[ format_str[i+1] - '0' ] = address + offset;
				}
				else if ((format_str[i+2] != 0) && (offset))
				{
					if ( (ByteAt(address + offset -1) == 0xEB) || ((ByteAt(address + offset -1) >= 0x70) && (ByteAt(address + offset -1) <= 0x7F)) )
					{
						label.Add( format_str[i+1] - '0' );
						goto_from.Add(address + offset);
						SetByteAt(address + offset, 0);
						offset += 1;
					}
					else if ( (ByteAt(address + offset -1) == 0xE8) || (ByteAt(address + offset -1) == 0xE9) )
					{
						label.Add( format_str[i+1] - '0' );
						goto_from.Add(address + offset);
						SetDwordAt(address + offset, 0);
						offset += 4;
					}
					else if (offset > 1)
					{
						if ( (ByteAt(address + offset -2) == 0x0F) && (ByteAt(address + offset -1) >= 0x80) && (ByteAt(address + offset -1) <= 0x8F) )
						{
							label.Add( format_str[i+1] - '0' );
							goto_from.Add(address + offset);
							SetDwordAt(address + offset, 0);
							offset += 4;
						}
					}
				}
				i += 2;
			}
			continue;
		}

		if (format_str[i] == '%')
		{
			switch (format_str[i+1])
			{
				case 0:
					i++;
					break;

				case 'h':
				case '%':
					p_arg += 4;
					Process(CStrAt(p_arg - 4));
					i++;
					break;

				case 'd':
					SetDwordAt(address + offset, IntAt(p_arg));
					offset += 4;
					p_arg += 4;
					i++;
					break;

				case 'w':
					SetWordAt(address + offset, IntAt(p_arg));
					offset += 2;
					p_arg += 4;
					i++;
					break;

				case 'b':    
					SetByteAt(address + offset, IntAt(p_arg));
					offset += 1;
					p_arg += 4;
					i++;
					break;

				case 'c':
					SetCallAt(address + offset, PtrAt(p_arg));
					offset += 5;
					p_arg += 4;
					i++;
					break;

				case 'j':     
					SetJmpAt(address + offset, PtrAt(p_arg));
					offset+=5;
					p_arg += 4;
					i++;
					break;

				case 'n':
					MemSet(address + offset, 0x90, DwordAt(p_arg));
					offset += DwordAt(p_arg);
					p_arg += 4;
					i++;
					break;

				case 'm': 
					offset += __MemCopyCode(address + offset, PtrAt(p_arg), PtrAt(p_arg + 4), TRUE);
					p_arg += 8;
					i++;
					break;

				case 'a': 
					PtrAt(PtrAt(p_arg)) = address + offset;
					p_arg += 4;
					i++;
					break;

				case 'o': 
					PtrAt(PtrAt(p_arg)) = offset;
					p_arg += 4;
					i++;
					break;

				case '.': 
					i++;
					break;

				default: 
					i++;
			}
			continue;
		}

		for (int d = 0; d < 16; d++)
		{
			if (format_str[i] == digits[d])
			{
				if (have_first_digit)
				{
					n += d;
					SetByteAt(address + offset, n);
					offset++;
					have_first_digit = FALSE;
				}
				else
				{
					n = (d << 4);
					have_first_digit = TRUE;
				}
				break;
			}
		}
	}

	for (int i = 0; i < label.Count(); i++)
	{
		if (goto_from[i] - address)
		{
			if ( (ByteAt(goto_from[i]-1) == 0xEB) || ((ByteAt(goto_from[i]-1) >= 0x70) && (ByteAt(goto_from[i]-1) <= 0x7F)) )
			{
				int adr = goto_to[label[i]] - goto_from[i] - 1;
				if ( (adr >= -127) && (adr <= 127) )
					*(char*)(goto_from[i]) = (char)adr;
			}
			else if ( (ByteAt(goto_from[i]-1) == 0xE8) || (ByteAt(goto_from[i]-1) == 0xE9) )
			{
				SetDwordAt(goto_from[i], goto_to[label[i]] - goto_from[i] - 4);
			}
			else if ((goto_from[i] - address) > 1)
			{
				if ( (ByteAt(goto_from[i]-2) == 0x0F) && (ByteAt(goto_from[i]-1) >= 0x80) && (ByteAt(goto_from[i]-1) <= 0x8F) )
				{
					SetDwordAt(goto_from[i], goto_to[label[i]] - goto_from[i] - 4);
				}
			}
		}
	}

}


int _WriteCodeStringVA(_ptr_ address, char* hex_string, _dword_* args, int* p_read_args_count, int pr)
{
	CodeWriter csw = CodeWriter(address, args);
	csw.Process(hex_string);
	return csw.offset;
}

int _WriteCodeString(_ptr_ address, char* hex_string, ...)
{
	CodeWriter csw = CodeWriter(address, ((_dword_*)(&hex_string)) + 1);
	csw.Process(hex_string);
	return csw.offset;
}

int _WriteDataStringVA(_ptr_ address, char* hex_string, _dword_* args, int* p_read_args_count, int pr)
{
	DataWriter dsw = DataWriter(address, args);
	dsw.Process(hex_string);
	return dsw.offset;
}

int _WriteDataString(_ptr_ address, char* hex_string, ...)
{
	DataWriter dsw = DataWriter(address, ((_dword_*)(&hex_string)) + 1);
	dsw.Process(hex_string);
	return dsw.offset;
}


Patch*	PatcherInstance::CreateHexPatch(_ptr_ address, char *hex_str)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	_dword_ sz = _WriteHexString((_ptr_)patch_buffer, hex_str);
	return CreatePatch(address, (_ptr_)patch_buffer, sz, FALSE);
}
Patch*	PatcherInstance::WriteHexPatch(_ptr_ address, char *hex_str)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	Patch* p = CreateHexPatch(address, hex_str);
	p->Apply();
	return p;
}


Patch*	PatcherInstance::CreateCodePatchVA(_ptr_ address, char *hex_str, _dword_* va_args)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	_dword_ sz = _WriteCodeStringVA((_ptr_)patch_buffer, hex_str, va_args);
	return CreatePatch(address, (_ptr_)patch_buffer, sz, TRUE);
}



Patch*	PatcherInstance::WriteCodePatchVA(_ptr_ address, char *hex_str, _dword_* va_args)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	Patch* p = CreateCodePatchVA(address, hex_str, va_args);
	p->Apply();
	return p;
}

Patch*	PatcherInstance::CreateDataPatchVA(_ptr_ address, char *hex_str, _dword_* va_args)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	_dword_ sz = _WriteDataStringVA((_ptr_)patch_buffer, hex_str, va_args);
	return CreatePatch(address, (_ptr_)patch_buffer, sz, FALSE);
}



Patch*	PatcherInstance::WriteDataPatchVA(_ptr_ address, char *hex_str, _dword_* va_args)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, PATCH_));
		return NULL;
	}
	Patch* p = CreateDataPatchVA(address, hex_str, va_args);
	p->Apply();
	return p;
}

void CalculateHookSize(Patch* hook)
{
	hook->size = _GetNeedCodeLength((BYTE*)(hook->address), 5);

	if (hook->size == 0)
	{
		//ERROR!!!
		ShowErrMsg("FATAL ERROR! Cann't create Hook at 0x%.8X! Unknown opcode.", hook->address);
		BREAKPOINT;
	}

	while(ByteAt(hook->address + hook->size) == 0x90) hook->size++;
}

LoHook::LoHook(_ptr_ address, void *f, _dword_ stack_delta)
{
	//////// ���� ���� ��������������� �� ����� ��� ���������� pushfd �����, ����� trap flag
	//////"9C %%",	 // pushfd
	//////"58 %%",	 // pop eax
	//////"25 00010000 %%",	// and eax, 0x00000100
	//////"0D FFFEFFFF %%",	// or eax, 0xFFFFEFFF
	//////"59 %%",	 // pop ecx
	//////"21 C1 %%",	 // and ecx, eax
	//////"51 %%",	 // push ecx
	//////"9D %%",	 // popfd

	this->address = address;
	this->func = (_ptr_)f;
	this->flags = PF_CODE | PF_LOHOOK;
	this->parent = NULL;
	this->node = NULL;


	CalculateHookSize(this);

	//int bridge_size = _WriteCodeString((_ptr_)patch_buffer,

	//	"A3    %d %%", &context->eax,// mov [&context->eax], eax

	//	"89 0D %d %%", &context->ecx,// mov [&context->ecx], ecx
	//	"89 15 %d %%", &context->edx,// mov [&context->edx], edx
	//	"89 1D %d %%", &context->ebx,// mov [&context->ebx], ebx
	//	"89 25 %d %%", &context->esp,// mov [&context->esp], esp
	//	"89 2D %d %%", &context->ebp,// mov [&context->ebp], ebp
	//	"89 35 %d %%", &context->esi,// mov [&context->esi], esi
	//	"89 3D %d %%", &context->edi,// mov [&context->edi], edi

	//	"9C %%", //pushfd
	//	"58 %%", //pop eax
	//	"A3    %d %%", &context->flags,// mov [&flags_register], eax

	//	"B8    %d %%", address + size,		// mov eax, (address + size)
	//	"A3    %d %%", &context->return_address,		// mov [&context->return_address], eax

	//	"68 %d %%", context,					// push context  // 
	//	"68 %d %%", this,						// push this  // 
	//	"%c %%", func,							// call func  // 

	//	"8B 0D %d %%", &context->ecx,// mov ecx, [&context->ecx]
	//	"8B 15 %d %%", &context->edx,// mov edx, [&context->edx]
	//	"8B 1D %d %%", &context->ebx,// mov ebx, [&context->ebx]
	//	"8B 25 %d %%", &context->esp,// mov esp, [&context->esp]
	//	"8B 2D %d %%", &context->ebp,// mov ebp, [&context->ebp]
	//	"8B 35 %d %%", &context->esi,// mov esi, [&context->esi]
	//	"8B 3D %d %%", &context->edi,// mov edi, [&context->edi]

	//	"83 F8 00 %%",							// cmp eax, NO_EXEC_DEFAULT
	//	"75 #1 %%", //JNE SHORT #1

	//		"A1    %d %%", &context->flags, // mov eax, [&context->flags]
	//		"50 %%",	//push eax
	//		"9D %%",    //popfd
	//		"A1    %d %%", &context->eax,// mov eax, [&context->eax]
	//		
	//		"FF 25 %d %%", &context->return_address,

	//	"#1: %%",

	//		"A1    %d %%", &context->flags, // mov eax, [&context->flags]
	//		"50 %%",	//push eax
	//		"9D %%",    //popfd
	//		"A1    %d %%", &context->eax,// mov eax, [&context->eax]

	//		"%o %m %%", &tail_code, address, size,						// exec default code

	//		"FF 25 %d %.", &context->return_address);

	int bridge_size = _WriteCodeString((_ptr_)patch_buffer,

		"89 25 %d %%", &esp_register,// mov [&esp_register], esp
		"9C %%", //pushfd
		"8F 05 %d %%", &flags_register, // pop [&flags_register]
		"81 EC %d %%", stack_delta, // sub esp, stack_delta
		"FF 35 %d %%", &flags_register, // push [&flags_register]
		"68 %d %%", address + size,
		"57 56 55 %%", //push edi  push esi  push ebp
		"FF 35 %d %%", &esp_register, // push [&esp_register]
		"53 52 51 50 %%", // push ebx  push edx  push ecx  push eax  
		
		"54 %%", // push esp (context)
		"68 %d %%", this,						// push this  // 
		"%c %%", func,							// call func  // 

		"83 F8 00 %%",							// cmp eax, NO_EXEC_DEFAULT
		"75 #1 %%", //JNE SHORT #1

			"58 59 5A 5B %%", //pop eax  pop ecx  pop edx  pop ebx
			"8F 05 %d %%", &esp_register, // pop [&esp_register]
			"5D 5E 5F %%", //pop ebp  pop esi  pop edi
			"8F 05 %d %%", &return_address, // pop [&return_address]
			"9D %%",
			"8B 25 %d %%", &esp_register,// mov esp, [&esp_register]
			
			"FF 25 %d %%", &return_address,

		"#1: %%",

			"58 59 5A 5B %%", //pop eax  pop ecx  pop edx  pop ebx
			"8F 05 %d %%", &esp_register, // pop [&esp_register]
			"5D 5E 5F %%", //pop ebp  pop esi  pop edi
			"8F 05 %d %%", &return_address, // pop [&return_address]
			"9D %%",
			"8B 25 %d %%", &esp_register,// mov esp, [&esp_register]
			
			"%o %m %%", &tail_code, address, size,						// exec default code

			"FF 25 %d %.", &return_address);

	bridge_to_func = CodeAlloc(bridge_size + 6 + 6 + 15 - 5);
	tail_code += bridge_to_func;
	__MemCopyCode(bridge_to_func, (_ptr_)patch_buffer, bridge_size);

	///////////////////
	//old_data = MemAlloc(size);
	//new_data = MemAlloc(size);
	//MemSet(new_data, 0x90, size); // nops
	old_data = MemAlloc(4 + 15);
	new_data = MemAlloc(4 + 15);
	MemSet(new_data, 0x90, 4 + 15); // nops
	SetJmpAt(new_data, bridge_to_func);
}
LoHook::~LoHook()
{
	MemFree(bridge_to_func);
}


HexHook::HexHook(_ptr_ address, _bool_ ed, _ptr_ csz, _ptr_ c)
{
	this->address = address;
	this->exec_default = ed;
	this->flags = PF_CODE | PF_LOHOOK;
	this->parent = NULL;
	this->node = NULL;
	this->tail_code = 0;

	CalculateHookSize(this);

	int code_size;

	if (exec_default)
	{
		code_size = _WriteCodeString((_ptr_)patch_buffer,
			"%m %%", c, csz,
			"%o %m %%", &tail_code, address, size,
			"%j %.", address + size);
	}
	else
	{
		code_size = _WriteCodeString((_ptr_)patch_buffer,
			"%m %%", c, csz,
			"%j %.", address + size);
	}
	this->code = CodeAlloc(code_size);
	this->tail_code += this->code;
	__MemCopyCode(this->code, (_ptr_)patch_buffer, code_size);

	///////////////////
	//old_data = MemAlloc(size);
	//new_data = MemAlloc(size);
	//MemSet(new_data, 0x90, size); // nops
	old_data = MemAlloc(4 + 15);
	new_data = MemAlloc(4 + 15);
	MemSet(new_data, 0x90, 4 + 15); // nops
	SetJmpAt(new_data, this->code);
}
HexHook::~HexHook()
{
	MemFree(code);
}

_bool_ HexHook::Apply()
{
	if (IsApplied()) return -2;

	CalculateHookSize(this);

	if (exec_default)
	{
		_WriteCodeString(tail_code, 
			"%m %%", address, size,						// exec default code
			"%j %.", address + size);
	}

	return Patch::Apply();
}
HexHook* PatcherInstance::CreateHexHookVA(_ptr_ address, _bool_ exec_default, char* hex_str, _dword_* va_args)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	_dword_ sz = _WriteCodeStringVA((_ptr_)patch_buffer, hex_str, va_args);
	_ptr_ code = MemAlloc(sz);
	__MemCopyCode(code, (_ptr_)patch_buffer, sz, TRUE);
	HexHook* h = new HexHook(address, exec_default, sz,(_ptr_)code);
	MemFree(code);
	h->parent = this;
	patches.Add(h);
	return h;
}
HexHook* PatcherInstance::WriteHexHookVA(_ptr_ address, _bool_ exec_default, char* hex_str, _dword_* va_args)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	HexHook* h = CreateHexHookVA(address, exec_default, hex_str, va_args);
	h->Apply();
	return h;
}


LoHook* PatcherInstance::CreateLoHookEx(_ptr_ address, void* func, _dword_ stack_delta)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	LoHook* h = new LoHook(address, func, stack_delta);
	h->parent = this;
	patches.Add(h);
	return h;
}
LoHook* PatcherInstance::WriteLoHookEx(_ptr_ address, void* func, _dword_ stack_delta)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	LoHook* h = CreateLoHookEx(address, func, stack_delta);
	h->Apply();
	return h;
}



LoHook* PatcherInstance::CreateLoHook(_ptr_ address, void* func)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	LoHook* h = new LoHook(address, func);
	h->parent = this;
	patches.Add(h);
	return h;
}
LoHook* PatcherInstance::WriteLoHook(_ptr_ address, void* func)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	LoHook* h = CreateLoHook(address, func);
	h->Apply();
	return h;
}

void PatcherInstance::BlockAt(_ptr_ address)
{
	blocks.Add(address);
}

HiHook::HiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* f)
{
	this->hooktype = hooktype;
	this->subtype = subtype;
	this->calltype = calltype;
	this->address = address;
	this->flags = (PF_CODE*(hooktype != FUNCPTR_)) | PF_HIHOOK;
	this->parent = NULL;
	this->user_data = 0;

	if (hooktype == FUNCPTR_)
		size = 4;
	else
		CalculateHookSize(this);

	this->new_func = (_ptr_)f;
	this->node = NULL;
	this->bridge_to_new = NULL;
	this->bridge_to_default = NULL;
	this->context = NULL;

	_ptr_ code_to_call = new_func;

	_dword_ bridge_to_new_size = 0;

	if (subtype == SAFE_)
	{
		this->context = new HookContext;

		//////char* push_register_args = " %%";
		//////char* pop_hook = " %%";

		//////switch(calltype)
		//////{
		//////	case CDECL_:	pop_hook = "83 C4 04 %%";			break;	// add esp,4 (~ pop hook)
		//////	case THISCALL_: push_register_args = "51 %%";		break;  // push ecx
		//////	case FASTCALL_: push_register_args = "52 51 %%";	break;  // push edx; push ecx
		//////}
		//////bridge_to_new_size = _WriteCodeString((_ptr_)patch_buffer,
		//////	"A3    %d %%", &context->eax,// mov [&hook->eax], eax
		//////	"89 0D %d %%", &context->ecx,// mov [&hook->ecx], ecx
		//////	"89 15 %d %%", &context->edx,// mov [&hook->edx], edx
		//////	"89 1D %d %%", &context->ebx,// mov [&hook->ebx], ebx
		//////	"89 35 %d %%", &context->esi,// mov [&hook->esi], esi
		//////	"89 3D %d %%", &context->edi,// mov [&hook->edi], edi

		//////	"58 %%",							// pop eax (retn address)
		//////	"A3 %d %%", &return_address,		// mov [&return_address], eax

		//////	push_register_args,					// nop / push ecx / push edx; push ecx 
		//////	"68 %d %%", this,						// push hook
		//////	"%c %%", new_func,						// call new_func
		//////	pop_hook,							// nop / add esp,4 (~ pop hook)

		//////	"FF 25 %d %.", &return_address); // jmp [&return_address]
		//////bridge_to_new = MemAlloc(bridge_to_new_size);
		//////VirtualProtect((LPVOID)bridge_to_new, (SIZE_T)(bridge_to_new_size) , PAGE_EXECUTE_READWRITE, NULL);
		//////__MemCopyCode(bridge_to_new, (_ptr_)patch_buffer, bridge_to_new_size);

		//////code_to_call = bridge_to_new;

		char* push_register_args = " %%";

		switch(calltype)
		{
		case CDECL_:
			{
				bridge_to_new_size = _WriteCodeString((_ptr_)patch_buffer,
					"A3    %d %%", &context->eax,// mov [&hook->eax], eax
					"89 0D %d %%", &context->ecx,// mov [&hook->ecx], ecx
					"89 15 %d %%", &context->edx,// mov [&hook->edx], edx
					"89 1D %d %%", &context->ebx,// mov [&hook->ebx], ebx
					"89 35 %d %%", &context->esi,// mov [&hook->esi], esi
					"89 3D %d %%", &context->edi,// mov [&hook->edi], edi

					"58 %%",							// pop eax (retn address)
					"A3 %d %%", &return_address,		// mov [&return_address], eax

					"68 %d %%", this,						// push hook
					"%c %%", new_func,						// call new_func
					"83 C4 04 %%",						// add esp,4 (~ pop hook)

					"FF 25 %d %.", &return_address); // jmp [&return_address]
				bridge_to_new = CodeAlloc(bridge_to_new_size);
				__MemCopyCode(bridge_to_new, (_ptr_)patch_buffer, bridge_to_new_size);

			}
			break;

		case STDCALL_:
		case THISCALL_:
		case FASTCALL_:
			{
				switch(calltype)
				{
					case STDCALL_:  push_register_args = " %%";			break; 
					case THISCALL_: push_register_args = "51 %%";		break;  // push ecx
					case FASTCALL_: push_register_args = "52 51 %%";	break;  // push edx; push ecx
				}
				
				bridge_to_new_size = _WriteCodeString((_ptr_)patch_buffer,
					"A3    %d %%", &context->eax,// mov [&hook->eax], eax
					"89 0D %d %%", &context->ecx,// mov [&hook->ecx], ecx
					"89 15 %d %%", &context->edx,// mov [&hook->edx], edx
					"89 1D %d %%", &context->ebx,// mov [&hook->ebx], ebx
					"89 35 %d %%", &context->esi,// mov [&hook->esi], esi
					"89 3D %d %%", &context->edi,// mov [&hook->edi], edi

					"58 %%",							// pop eax (retn address)
					"A3 %d %%", &return_address,		// mov [&hook->return_adress], eax  
					push_register_args,					// nop / push ecx / push edx; push ecx 
					"68 %d %%", this,					// push hook
					"50 %%",							// push eax
					"%j %.", new_func);					// jmp new_func
				bridge_to_new = CodeAlloc(bridge_to_new_size);
				__MemCopyCode(bridge_to_new, (_ptr_)patch_buffer, bridge_to_new_size);

			}
			break;
		}
		code_to_call = bridge_to_new;

		this->old_data = MemAlloc(size);
		this->new_data = MemAlloc(size);

		///////////////////////////////////////////

		_dword_ o_eax, o_ecx, o_edx, o_ebx, o_esi, o_edi, o_ret;
		_dword_ os_eax, os_ecx, os_edx, os_ebx, os_esi, os_edi, os_ret;
		_dword_ ol_eax, ol_ecx, ol_edx, ol_ebx, ol_esi, ol_edi, ol_ret;
		_dword_ o_def_bridge;
		_dword_ def_size;

		def_size = _WriteCodeString((_ptr_)patch_buffer,
			"58 %%",							// pop eax (retn address)
			"A3 %o %d %%", &os_ret, 0,		// mov [&return_address], eax

			"89 0D %o %d %%", &os_ecx, 0,// mov [&hook->ecx], ecx
			"89 1D %o %d %%", &os_ebx, 0,// mov [&hook->ebx], ebx
			"89 35 %o %d %%", &os_esi, 0,// mov [&hook->esi], esi
			"89 3D %o %d %%", &os_edi, 0,// mov [&hook->edi], edi

			"A1    %d %%", &context->eax,// mov eax, [&hook->eax]
			"EB %b %%", ((calltype == THISCALL_) || (calltype == FASTCALL_)) * 6 + (calltype == FASTCALL_) * 6,
			"8B 0D %d %%", &context->ecx,// mov ecx, [&hook->ecx]
			"8B 15 %d %%", &context->edx,// mov edx, [&hook->edx]
			"8B 1D %d %%", &context->ebx,// mov ebx, [&hook->ebx]
			"8B 35 %d %%", &context->esi,// mov esi, [&hook->esi]
			"8B 3D %d %%", &context->edi,// mov edi, [&hook->edi]

			"E8 #1 %%", // call default

			"8B 0D %o %d %%", &ol_ecx, 0,// mov ecx, [&hook->ecx]
			"8B 1D %o %d %%", &ol_ebx, 0,// mov ebx, [&hook->ebx]
			"8B 35 %o %d %%", &ol_esi, 0,// mov esi, [&hook->esi]
			"8B 3D %o %d %%", &ol_edi, 0,// mov edi, [&hook->edi]

			"FF 25 %o %d %%", &ol_ret, 0,// jmp [&return_address]

			"#1: %o %n %%", &o_def_bridge, 6 + 6 + 15 + 5,

			"%o 00 00 00 00 %%", &o_ecx,
			"%o 00 00 00 00 %%", &o_ebx,
			"%o 00 00 00 00 %%", &o_esi,
			"%o 00 00 00 00 %%", &o_edi,
			"%o 00 00 00 00 %.", &o_ret	);

		default_func = CodeAlloc(def_size);
		__MemCopyCode(default_func, (_ptr_)patch_buffer, def_size);
		bridge_to_default = default_func + o_def_bridge;

		DwordAt(default_func + os_ecx) = default_func + o_ecx;
		DwordAt(default_func + os_ebx) = default_func + o_ebx;
		DwordAt(default_func + os_esi) = default_func + o_esi;
		DwordAt(default_func + os_edi) = default_func + o_edi;
		
		DwordAt(default_func + ol_ecx) = default_func + o_ecx;
		DwordAt(default_func + ol_ebx) = default_func + o_ebx;
		DwordAt(default_func + ol_esi) = default_func + o_esi;
		DwordAt(default_func + ol_edi) = default_func + o_edi;

		DwordAt(default_func + os_ret) = default_func + o_ret;
		DwordAt(default_func + ol_ret) = default_func + o_ret;

		_ptr_ func;

		switch (hooktype)
		{
		case CALL_:
			if (ByteAt(address) == 0xE8) // call n32 opcode
				_WriteCodeString(bridge_to_default,	"%j %.", PtrAt(address + 1) + address + 5); 
			else if ( (ByteAt(address) == 0xFF) && (ByteAt(address+1) == 0x15) ) // call [n32] opcode
				_WriteCodeString(bridge_to_default,	"%j %.", PtrAt(PtrAt(address + 2)) ); 

			MemSet(new_data, 0x90, size);
			SetCallAt(new_data, code_to_call);
			break;

		case SPLICE_:
			_WriteCodeString(bridge_to_default,
				"%m %%", address, size,
				"%j %.", address + size);
			MemSet(new_data, 0x90, size);
			SetJmpAt(new_data, code_to_call);
			break;

		case FUNCPTR_:
			_WriteCodeString(bridge_to_default,	"%j %.", DwordAt(address));
			SetDwordAt(new_data, code_to_call);
			break;
		}

		return;
	}

	/////////////////////////////////////////////////////////////////////////////////////////////////

	if (subtype == EXTENDED_)
	{
		char* push_register_args = " %%";

		switch(calltype)
		{
		case CDECL_:
			{
				bridge_to_new_size = _WriteCodeString((_ptr_)patch_buffer,
					"58 %%",							// pop eax (retn address)
					"A3 %d %%", &return_address,		// mov [&return_address], eax

					"68 %d %%", this,						// push hook
					"%c %%", new_func,						// call new_func
					"83 C4 04 %%",						// add esp,4 (~ pop hook)

					"FF 25 %d %.", &return_address); // jmp [&return_address]
				bridge_to_new = CodeAlloc(bridge_to_new_size);
				__MemCopyCode(bridge_to_new, (_ptr_)patch_buffer, bridge_to_new_size);

			}
			break;

		case STDCALL_:
		case THISCALL_:
		case FASTCALL_:
			{
				switch(calltype)
				{
					case STDCALL_:  push_register_args = " %%";			break; 
					case THISCALL_: push_register_args = "51 %%";		break;  // push ecx
					case FASTCALL_: push_register_args = "52 51 %%";	break;  // push edx; push ecx
				}
				
				bridge_to_new_size = _WriteCodeString((_ptr_)patch_buffer,
					"58 %%",							// pop eax (retn address)
					"A3 %d %%", &return_address,		// mov [&hook->return_adress], eax  
					push_register_args,					// nop / push ecx / push edx; push ecx 
					"68 %d %%", this,					// push hook
					"50 %%",							// push eax
					"%j %.", new_func);					// jmp new_func
				bridge_to_new = CodeAlloc(bridge_to_new_size);
				__MemCopyCode(bridge_to_new, (_ptr_)patch_buffer, bridge_to_new_size);

			}
			break;
		}
		code_to_call = bridge_to_new;
	}

	this->old_data = MemAlloc(size);
	this->new_data = MemAlloc(size);

	///////////////////////////////////////////
	switch (hooktype)
	{
	case CALL_:
		if (*(_byte_*)address == 0xE8) // call n32 opcode
		{
			default_func = *(_ptr_*)(address + 1) + address + 5; 
		}
		else if ( (*(_byte_*)address == 0xFF) && (*(_byte_*)(address+1) == 0x15) ) // call [n32] opcode
		{
			default_func = *(_ptr_*)(*(_ptr_*)(address + 2)); 
		}
		else
		{
			default_func = NULL; 
			//ShowErrMsg("Cann't create ? CALL_ HiHook at 0x%.8X. Wrong opcode: %.1X %.1X !", address, *(_byte_*)address, *(_byte_*)(address+1) );
			//BREAKPOINT;
		}
		MemSet(new_data, 0x90, size);
		SetCallAt(new_data, code_to_call);
		break;

	case SPLICE_:
		{
			bridge_to_default = CodeAlloc(6 + 6 + 15 + 5);
			MemSet(bridge_to_default, 0x90, 6 + 6 + 15 + 5);
			_WriteCodeString(bridge_to_default,
				//"CD 03 %%",
				"%m %%", address, size,
				"%j %.", address + size);
			default_func = bridge_to_default;

			MemSet(new_data, 0x90, size);
			SetJmpAt(new_data, code_to_call);
		}
		break;

	case FUNCPTR_:
		default_func = DwordAt(address);
		SetDwordAt(new_data, code_to_call);
		break;
	}
}
HiHook::~HiHook()
{
	if (subtype == SAFE_)
	{
		MemFree(default_func);
		delete context;
	}
	else
		MemFree(bridge_to_default);

	MemFree(bridge_to_new);
}
HiHook* PatcherInstance::CreateHiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* new_func)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	HiHook* h = new HiHook(address, hooktype, subtype, calltype, new_func);
	patches.Add(h);
	h->parent = this;
	return h;
}
HiHook* PatcherInstance::WriteHiHook(_ptr_ address, int hooktype, int subtype, int calltype, void* new_func)
{
	HMODULE hm = GetModuleHandleFromAddress(GetFuncReturnAdress(address));
	if ( (hm != hmodule) && (hm != Px86.hmodule) )
	{
		if (Px86.logging_on) log.Add(new LogRecord(LM_ERR_INSTANCE, this, address, 0, LOHOOK_));
		return NULL;
	}
	HiHook* h = CreateHiHook(address, hooktype, subtype, calltype, new_func);
	h->Apply();
	return h;
}

PatcherInstance::~PatcherInstance()
{
	MemFree(name);
}

_Var_* Patcher::VarInit(char* name, _dword_ value)
{
	_Var_* v = Vars.Find(name);
	if (v)
		v->value = value;
	else
		v = Vars.Add(name, value);
	return v;
}
_Var_* Patcher::VarFind(char* name)
{
	return Vars.Find(name);
}


int __stdcall __GetFuncReturnArgsCount(_ptr_ func)
{
	int i = 0;
	int ol = 0;
	while(true)
	{
		int ol = _GetNeedCodeLength((_byte_*)(func + i), 1);
		if (ol == 0) return 0;
		if (ol == 1) if (ByteAt(func + i) == 0xC3) return 0;
		if (ol == 3) if (ByteAt(func + i) == 0xC2) return (WordAt(func + i + 1) / 4);
		i += ol;
	}
}

int __stdcall __MemCopyCode(_ptr_ dst, _ptr_ src, _dword_ size, _bool_ transform_short_jumps)
{

	int si = 0;
	int di = 0;

	while(si < size)
	{
		int ol = _GetNeedCodeLength((_byte_*)(src + si), 1);

		switch (ol)
		{
		case 2:
			if (transform_short_jumps)
			{
				if	(ByteAt(src + si) == 0xEB)
				{
					_dword_ to_abs = (src + si) + (int)*(signed __int8 *)(src + si + 1) + 2;
					if ( (to_abs < src) || (to_abs > (src + size)) )
					{
						ByteAt(dst + di) = 0xE9;
						DwordAt(dst + di + 1) = to_abs - (dst + di) - 5;
						di += 5;
						break;
					}
				}
				else if ( (ByteAt(src + si) >= 0x70) && (ByteAt(src + si) <= 0x7F) )
				{
					_dword_ to_abs = (src + si) + (int)*(signed __int8 *)(src + si + 1) + 2;
					if ( (to_abs < src) || (to_abs > (src + size)) )
					{
						ByteAt(dst + di) = 0x0F;
						ByteAt(dst + di + 1) = ByteAt(src + si) + 0x10;
						DwordAt(dst + di + 2) = to_abs - (dst + di) - 6;
						di += 6;
						break;
					}
				}
			}

			MemCopy(dst + di, src + si, ol);
			di += ol;
			break;

		case 5:
			if (ByteAt(src + si) == 0xE8)
			{
				_dword_ to_abs = DwordAt( (src + si) + 1 ) + (src + si) + 5;
				if ( (to_abs < src) || (to_abs > (src + size)) )
					SetCallAt(dst + di, to_abs);
				else
					MemCopy(dst + di, src + si, ol);
			}
			else if (ByteAt(src + si) == 0xE9)
			{
				_dword_ to_abs = DwordAt( (src + si) + 1 ) + (src + si) + 5;
				if ( (to_abs < src) || (to_abs > (src + size)) )
					SetJmpAt(dst + di, to_abs);
				else
					MemCopy(dst + di, src + si, ol);
			}
			else
				MemCopy(dst + di, src + si, ol);
			
			di += ol;
			break;

		case 6:
			if ( (ByteAt(src + si) == 0x0F) && (ByteAt(src + si + 1) >= 0x80) && (ByteAt(src + si + 1) <= 0x8F) )
			{
				_dword_ to_abs = DwordAt( (src + si) + 2 ) + (src + si) + 6;
				if ( (to_abs < src) || (to_abs > (src + size)) )
				{
					WordAt(dst + di) = WordAt(src + si);
					DwordAt(dst + di + 2) = to_abs - (dst + di) - 6;
				}
				else
					MemCopy(dst + di, src + si, ol);
			}
			else
				MemCopy(dst + di, src + si, ol);
			
			di += ol;
			break;

		default:
			MemCopy(dst + di, src + si, ol);
			
			di += ol;
			break;
		}		
		si += ol;
	}
	return di;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int _GetNeedCodeLength(_byte_* p_code, int need_len)
{
	int full_len = 0;
	int o_len;

	do
	{
		__asm push esi
		o_len = _GetOpcodeLength(p_code + full_len);
		__asm pop esi

		if (!o_len)
		{
			return 0;
		}
		full_len += o_len;
	}
	while (full_len < need_len);

	return full_len;
}

#define _SALC		0xD6
#define _AAM		0xD4
#define NRM_TAB_LEN	53

#define DB __asm _emit

__declspec(naked) int __cdecl _GetOpcodeLength(_byte_* p_opcode)
{
	_asm
	{
		mov esi, [esp + 4]
		pushad
		push	000001510h
		push	0100101FFh
		push	0FFFFFF55h
		push	0FFFFFFF8h
		push	0F8FF7FA0h
		push	00F0EC40Dh
		push	007551004h
		push	001D005FFh
		push	0550D5D55h
		push	0555F0F88h
		push	0F3F3FFFFh
		push	00A0C1154h
		
		mov	edx, esi
		mov	esi, esp

		push	11001b
		push	10110000101011000000101110000000b
		push	10111111101100011111001100111110b
		push	00000000000100011110101001011000b
		mov	ebx, esp
		sub	esp, 110
		mov	edi, esp

		cld
		push	100
		pop	ecx
	xa_nxtIndx:
		bt	[ebx], ecx
		DB _SALC
			
		jnc	xa_is0
		lodsb
	xa_is0:
		stosb
		loop	xa_nxtIndx
		mov	esi, edx

		push	2
		pop	ebx
		mov	edx, ebx
	xa_NxtByte:
		lodsb
		push	eax
		push	eax
		cmp	al, 66h
		cmove	ebx, ecx
		cmp	al, 67h
		cmove	edx, ecx
		cmp	al, 0EAh
		je	xa_jmp
		cmp	al, 09Ah
		jne	xa_nocall

		inc	esi
	xa_jmp:
		lea	esi, [esi+ebx+3]
	xa_nocall:
		cmp	al, 0C8h
		je	xa_i16
		and	al, 0F7h
		cmp	al, 0C2h
		jne	xa_no16
	xa_i16:
		inc	esi
		inc	esi

	xa_no16:
		and	al, 0E7h
		cmp	al, 26h
		pop	eax
		je	xa_PopNxt
		cmp	al, 0F1h
		je	xa_F1
		and	al, 0FCh
		cmp	al, 0A0h
		jne	xa_noMOV
		lea	esi, [esi+edx+2]
	xa_noMOV:
		cmp	al, 0F0h
		je	xa_PopNxt
	xa_F1:
		cmp	al, 64h
	xa_PopNxt:
		pop	eax
		je	xa_NxtByte

		mov	edi, esp
		push	edx
		push	eax
		cmp	al, 0Fh
		jne	xa_Nrm
		lodsb
	xa_Nrm:
		pushfd
		DB _AAM
		DB 10h
		xchg	cl, ah
		cwde
		cdq
		xor	ebp, ebp
		popfd
		jne	xa_NrmGroup

		add	edi, NRM_TAB_LEN
		jecxz	xa_3
	xa_1:
		bt	[edi], ebp
		jnc	xa_2
		inc	edx
	xa_2:
		inc	ebp
		loop	xa_1
		jc	xa_3
		DB _SALC
		cdq
	xa_3:
		shl	edx, 1
		jmp	xa_ProcOpcode

	xa_NrmGroup:
		sub	cl, 4
		jns	xa_4
		mov	cl, 0Ch
		and	al, 7
	xa_4:
		jecxz	xa_4x
	xa_5:
		adc	dl, 1
		inc	ebp
		bt	[edi], ebp
		loop	xa_5
		jc	xa_ProcOpcode
	xa_4x:
		shr	al, 1

	xa_ProcOpcode:
		xchg	cl, al
		lea	edx, [edx*8+ecx]
		pop	ecx
		pop	ebp
		bt	[edi+2], edx
		jnc	xa_noModRM

		lodsb
		DB _AAM
		DB 8
		shl	ah, 4
		jnc	xa_isModRM
		js	xa_enModRM
	xa_isModRM:
		pushfd
		test	ebp, ebp
		jnz	xa_addr32	
		sub	al, 6
		jnz	xa_noSIB
		mov	al, 5
	xa_addr32:
		cmp	al, 4
		jne	xa_noSIB
		lodsb
		and	al, 7
	xa_noSIB:
		popfd
		jc	xa_iWD
		js	xa_i8
		cmp	al, 5
		jne	xa_enModRM
	xa_iWD:	
		add	esi, ebp
		inc	esi
	xa_i8:
		inc	esi

	xa_enModRM:
		test	ah, 60h
		jnz	xa_noModRM
		xchg	eax, ecx
		cmp	al, 0F6h
		je	xa_ti8
		cmp	al, 0F7h
		jne	xa_noModRM
		add	esi, ebx
		inc	esi
	xa_ti8:
		inc	esi

	xa_noModRM:
		shl	edx, 1
		bt	[edi+2+17], edx
		jnc	xa_Exit
		inc	edx
		bt	[edi+2+17], edx
		jnc	xa_im8
		adc	esi, ebx
	xa_im8:
		inc	esi

	xa_Exit:
		add	esp, 110+64
		sub	esi, [esp+4]
		mov	[esp+7*4], esi
		popad
		ret
	}
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

void ShowErrMsg(char* pFormat, ...)
{
	if (show_errs)
	{
		va_list Args;
		va_start( Args, pFormat );
		char Buffer[512];
		vsprintf( Buffer, pFormat, Args );
		va_end( Args );
		MessageBoxA(NULL, (LPCSTR)(Buffer), (LPCSTR)"patcher_x86", MB_OK);
	}
}

HMODULE GetModuleHandleFromAddress(_ptr_ address)
{
	HMODULE hm = NULL;
	if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS, (LPCSTR)address, &hm))
		return hm;
	return (HMODULE)NULL;

}


BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
    {
	case DLL_PROCESS_ATTACH:
        break;
	
	case DLL_PROCESS_DETACH:
		break;
	
	case DLL_THREAD_ATTACH:
		break;
	
	case DLL_THREAD_DETACH:
		break;
	}

    return TRUE;
}
